import http from 'node:http';
import { readFile } from 'node:fs/promises';
import { resolve, extname } from 'node:path';
import { createHash, randomBytes, timingSafeEqual } from 'node:crypto';
import { SqliteStore } from './lib/store.js';
import { DemoCalendarAdapter } from './lib/calendar.js';
import { GoogleRoutesAdapter, DemoRoutesAdapter } from './lib/travel.js';
import { JevSystemOneClient, boundedJevNotice, boundedJevWeek } from './lib/jev.js';
import { dateKeyInZone, generateCandidates, hardConstraint, isValidTimeZone, mondayOf, overlaps, shiftDay, zonedEpoch } from './lib/scheduling.js';
import { BookingService, Mutex } from './lib/booking.js';
import { hostTravelConstraints } from './lib/host-travel.js';
import { BookingLinks, BookingManagement } from './lib/booking-management.js';
import { GoogleAccounts } from './lib/google-accounts.js';
import { AddressSelectionCodec, PhotonAddressAdapter } from './lib/address-search.js';
import { DEFAULT_PROJECT_RULES, normalizeProjectRules, learnWorkload, arrangeWorkloadSlots, dayWorkload, rankCandidateSlots, weeklyDatePreference, weeklyWorkloadAlert } from './lib/workload.js';

const env = process.env;
const DEMO = env.DEMO_MODE !== 'false';
if (!DEMO && !env.APP_ENCRYPTION_KEY) throw new Error('APP_ENCRYPTION_KEY is required when DEMO_MODE=false');
const port = Number(env.PORT || 3030);
const encryptionSecret = env.APP_ENCRYPTION_KEY || randomBytes(32).toString('hex');
const db = new SqliteStore({ path: env.DATABASE_PATH || './data/jev-calendar.sqlite', encryptionSecret });
const defaultSettings = { hours: { start: 9, end: 18 }, timezone: 'Europe/Rome', timezoneSource: 'settings', timezoneUpdatedAt: null, durationMinutes: 30, baseLocation: '', baseLocationProvider: '', baseLocationProviderId: '', baseLocationCoordinates: null, minimumTravelBufferMinutes: 10, minimumBookingNoticeMinutes: 0 };
const getSettings = () => ({ ...defaultSettings, ...db.getSetting('settings', defaultSettings) });
const projectRules = () => normalizeProjectRules(db.getSetting('projectRules', DEFAULT_PROJECT_RULES));
const learningSignature = (settings, rules, zone) => JSON.stringify(['week-intelligence-v1', settings.hours, settings.minimumBookingNoticeMinutes, rules, zone]);
function currentLearning(settings, rules, zone) {
  const saved = db.getSetting('workloadLearning', null);
  return saved?.signature === learningSignature(settings, rules, zone) ? saved : null;
}
function effectiveNoticeMinutes(settings, learning) {
  const base = settings.minimumBookingNoticeMinutes;
  return Math.max(base, Number.isInteger(learning?.bookingNotice?.minutes) ? learning.bookingNotice.minutes : base);
}
const mime = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg' };
const baseUrl = env.APP_BASE_URL || `http://localhost:${port}`;
const google = new GoogleAccounts({ store: db, clientId: env.GOOGLE_CLIENT_ID, clientSecret: env.GOOGLE_CLIENT_SECRET, baseUrl });
// Account changes and bookings share one lock so invitations cannot switch accounts mid-flight.
const operations = new Mutex();
if (!DEMO) await google.migrate();
function cookies(request) { return Object.fromEntries((request.headers.cookie || '').split(';').filter(Boolean).map((item) => item.trim().split(/=(.*)/s)).map(([k, v]) => [k, decodeURIComponent(v || '')])); }
function json(response, status, body) { response.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }); response.end(JSON.stringify(body)); }
function setCookie(response, key, value, { maxAge, httpOnly = true } = {}) { response.setHeader('Set-Cookie', `${key}=${encodeURIComponent(value)}; Path=/; ${httpOnly ? 'HttpOnly;' : ''} SameSite=Lax; ${env.NODE_ENV === 'production' ? 'Secure; ' : ''}${maxAge ? `Max-Age=${maxAge};` : ''}`); }
async function body(request) { let text = ''; for await (const chunk of request) { text += chunk; if (text.length > 100_000) throw new Error('Request too large'); } try { return text ? JSON.parse(text) : {}; } catch { throw new Error('Invalid JSON'); } }
function owner(request) { return DEMO || db.validSession(cookies(request).jev_session); }
function requireOwner(request, response) { if (owner(request)) return true; json(response, 401, { error: 'Owner sign-in required' }); return false; }
function requireJaackOsRead(request, response) {
  const secret = env.JEV_JAACK_OS_READ_TOKEN;
  const authorization = request.headers.authorization || '';
  const supplied = /^Bearer ([A-Za-z0-9_-]+)$/.exec(authorization)?.[1];
  if (secret && secret.length >= 32 && supplied && timingSafeEqual(createHash('sha256').update(supplied).digest(), createHash('sha256').update(secret).digest())) return true;
  json(response, 401, { error: 'Integration authentication required' });
  return false;
}
function requireJaackOsWrite(request, response) {
  const secret = env.JEV_JAACK_OS_WRITE_TOKEN, readSecret = env.JEV_JAACK_OS_READ_TOKEN;
  const supplied = /^Bearer ([A-Za-z0-9_-]+)$/.exec(request.headers.authorization || '')?.[1];
  if (secret && secret.length >= 32 && secret !== readSecret && supplied &&
      timingSafeEqual(createHash('sha256').update(supplied).digest(), createHash('sha256').update(secret).digest())) return true;
  json(response, 401, { error: 'Owner write integration authentication required' });
  return false;
}
function calendarAdapter() { return DEMO ? new DemoCalendarAdapter() : google.calendar(); }
function ownerMutation(request, response) {
  if (!requireOwner(request, response)) return false;
  if (request.headers['x-jev-owner'] !== '1' || request.headers.origin !== new URL(baseUrl).origin) { json(response, 403, { error: 'Open the private dashboard to manage Google accounts' }); return false; }
  return true;
}
function jevClient() { return new JevSystemOneClient({ token: env.TYPESAFE_API_KEY }); }
const addressSearch = new PhotonAddressAdapter();
const addressSelections = new AddressSelectionCodec(env.APP_ENCRYPTION_KEY || 'demo-local-only');
function isWeekday(day) { const value = new Date(`${day}T12:00:00Z`).getUTCDay(); return value > 0 && value < 6; }
async function currentHostTimeZone(calendar, settings) {
  const deviceUpdate = Date.parse(settings.timezoneUpdatedAt || '');
  if (settings.timezoneSource === 'owner-device' && Number.isFinite(deviceUpdate) && Date.now() - deviceUpdate < 10 * 60_000 && isValidTimeZone(settings.timezone)) return { timezone: settings.timezone, source: 'owner-device' };
  try {
    const timezone = await calendar.timeZone();
    if (isValidTimeZone(timezone)) {
      if (timezone !== settings.timezone || settings.timezoneSource !== 'google-calendar') db.putSetting('settings', { ...settings, timezone, timezoneSource: 'google-calendar', timezoneUpdatedAt: new Date().toISOString() });
      return { timezone, source: 'google-calendar' };
    }
  } catch (error) { console.warn(`Google Calendar timezone lookup failed: ${error.message}`); }
  return { timezone: isValidTimeZone(settings.timezone) ? settings.timezone : 'Europe/Rome', source: 'settings' };
}
let workloadRefresh;
async function refreshWorkload() {
  if (DEMO) return null;
  if (workloadRefresh) return workloadRefresh;
  workloadRefresh = (async () => {
    const calendar = calendarAdapter(), settings = getSettings(), rules = projectRules();
    const host = await currentHostTimeZone(calendar, settings);
    const today = dateKeyInZone(Date.now(), host.timezone);
    const startDate = new Date(`${today}T12:00:00Z`); startDate.setUTCDate(startDate.getUTCDate() - 28);
    const startDay = startDate.toISOString().slice(0, 10);
    const start = new Date(zonedEpoch(startDay, 0, host.timezone)).toISOString();
    const end = new Date(zonedEpoch(today, 0, host.timezone)).toISOString();
    const [busy, events] = await Promise.all([calendar.freeBusy({ start, end }), calendar.events({ start, end, includeWorkload: true })]);
    const learned = learnWorkload({ startDay, days: 28, zone: host.timezone, hours: settings.hours, busy, events, rules });
    const upcoming = [];
    const date = new Date(`${today}T12:00:00Z`);
    while (upcoming.length < 5) {
      const day = date.toISOString().slice(0, 10);
      if (isWeekday(day)) upcoming.push(day);
      date.setUTCDate(date.getUTCDate() + 1);
    }
    const futureStart = new Date(zonedEpoch(upcoming[0], 0, host.timezone)).toISOString();
    const futureEnd = new Date(zonedEpoch(upcoming.at(-1), 24, host.timezone)).toISOString();
    const [futureBusy, futureEvents] = await Promise.all([calendar.freeBusy({ start: futureStart, end: futureEnd }), calendar.events({ start: futureStart, end: futureEnd, includeWorkload: true })]);
    const upcomingDays = upcoming.slice(0, 2).map(day => {
      const load = dayWorkload({ day, zone: host.timezone, hours: settings.hours, busy: futureBusy, events: futureEvents, rules });
      const typeMinutes = Object.values(load.projects).reduce((total, project) => {
        for (const [type, minutes] of Object.entries(project.typeMinutes)) total[type] += minutes;
        return total;
      }, { meetings: 0, focus: 0, deadline: 0 });
      return { busyMinutes: load.busyMinutes, typeMinutes };
    });
    const bookingNotice = await boundedJevNotice({ client: jevClient(), baseMinutes: settings.minimumBookingNoticeMinutes, baselineBusyMinutes: learned.baselineBusyMinutes, upcomingDays });
    const signal = weeklyWorkloadAlert({ days: upcoming, zone: host.timezone, hours: settings.hours, busy: futureBusy, events: futureEvents, rules, learning: learned });
    const weekAlert = signal ? { heavyDays: signal.heavyDays, busyMinutes: signal.busyMinutes, typicalBusyMinutes: signal.typicalBusyMinutes, ...await boundedJevWeek({ client: jevClient(), alert: signal }) } : null;
    const result = { ...learned, bookingNotice, weekAlert, signature: learningSignature(settings, rules, host.timezone) };
    db.putSetting('workloadLearning', result);
    return result;
  })().finally(() => { workloadRefresh = null; });
  return workloadRefresh;
}
async function refreshWorkloadIfDue() {
  if (DEMO || !google.list().length) return;
  const settings = getSettings(), rules = projectRules(), saved = db.getSetting('workloadLearning', null);
  const today = dateKeyInZone(Date.now(), settings.timezone);
  if (saved && dateKeyInZone(saved.updatedAt, settings.timezone) === today && saved.signature === learningSignature(settings, rules, settings.timezone)) return;
  try { await refreshWorkload(); } catch (error) { console.warn(`Daily workload refresh failed: ${error.message}`); }
}
async function availability(input, calendar = calendarAdapter(), snapshot = null, candidateLimit = 12) {
  const settings = snapshot?.settings || getSettings();
  const durationMinutes = Math.min(180, Math.max(15, Number(input.durationMinutes) || settings.durationMinutes));
  const host = snapshot?.host || await currentHostTimeZone(calendar, settings);
  const viewerTimeZone = isValidTimeZone(input.viewerTimeZone) ? input.viewerTimeZone : host.timezone;
  const fallbackDate = dateKeyInZone(Date.now() + 86_400_000, viewerTimeZone);
  const date = /^\d{4}-\d{2}-\d{2}$/.test(input.date) ? input.date : fallbackDate;
  const viewerStart = zonedEpoch(date, 0, viewerTimeZone), viewerEnd = zonedEpoch(date, 24, viewerTimeZone);
  const hostDays = [...new Set([dateKeyInZone(viewerStart, host.timezone), dateKeyInZone(viewerEnd - 1, host.timezone)])].sort().filter(isWeekday);
  if (!hostDays.length) return { date, durationMinutes, candidates: [], travel: { inPersonEventCount: 0, maximumBufferMinutes: settings.minimumTravelBufferMinutes, routeProvider: 'none', adviceSource: 'none' }, hostTimezone: host.timezone, hostTimezoneSource: host.source, viewerTimeZone, demo: DEMO };
  const start = new Date(zonedEpoch(hostDays[0], 0, host.timezone)).toISOString();
  const end = new Date(zonedEpoch(hostDays.at(-1), 24, host.timezone)).toISOString();
  const contextStart = new Date(zonedEpoch(mondayOf(hostDays[0]), 0, host.timezone)).toISOString();
  const contextEnd = new Date(zonedEpoch(shiftDay(mondayOf(hostDays.at(-1)), 12), 0, host.timezone)).toISOString();
  const [contextBusy, contextEvents] = snapshot
    ? [snapshot.busy.filter(item => overlaps(contextStart, contextEnd, item)), snapshot.events.filter(item => overlaps(contextStart, contextEnd, item))]
    : await Promise.all([calendar.freeBusy({ start: contextStart, end: contextEnd }), calendar.events({ start: contextStart, end: contextEnd, includeWorkload: true })]);
  const busy = contextBusy.filter(item => overlaps(start, end, item));
  const events = contextEvents.filter(item => overlaps(start, end, item));
  const rules = snapshot?.rules || projectRules(), learning = currentLearning(settings, rules, host.timezone);
  const notBefore = Date.now() + effectiveNoticeMinutes(settings, learning) * 60_000;
  const preliminary = hostDays.flatMap((day) => generateCandidates({ day, busy, durationMinutes, bufferMinutes: settings.minimumTravelBufferMinutes, hours: settings.hours, zone: host.timezone, limit: 96, notBefore })).filter((slot) => Date.parse(slot.start) >= viewerStart && Date.parse(slot.start) < viewerEnd).sort((a, b) => Date.parse(a.start) - Date.parse(b.start));
  const routes = DEMO ? new DemoRoutesAdapter() : new GoogleRoutesAdapter({ apiKey: env.GOOGLE_ROUTES_API_KEY });
  const travel = await hostTravelConstraints({ events, baseLocation: settings.baseLocation, routes, jevClient: jevClient(), candidates: preliminary, minimumMinutes: settings.minimumTravelBufferMinutes });
  const safe = preliminary.filter((slot) => !hardConstraint({ ...slot, busy: travel.constraints, bufferMinutes: settings.minimumTravelBufferMinutes }));
  const feedback = snapshot?.feedback || db.slotFeedback();
  const candidates = hostDays.flatMap(day => {
    const dayStart = new Date(zonedEpoch(day, 0, host.timezone)).toISOString(), dayEnd = new Date(zonedEpoch(day, 24, host.timezone)).toISOString();
    const dayBusy = busy.filter(item => overlaps(dayStart, dayEnd, item));
    const dayEvents = events.filter(item => overlaps(dayStart, dayEnd, item));
    const load = dayWorkload({ day, zone: host.timezone, hours: settings.hours, busy: dayBusy, events: dayEvents, rules });
    const meetingMinutes = Object.values(load.projects).reduce((sum, project) => sum + project.typeMinutes.meetings, 0);
    const arranged = arrangeWorkloadSlots({ day, candidates: safe.filter(slot => dateKeyInZone(slot.start, host.timezone) === day), zone: host.timezone, hours: settings.hours, busy: dayBusy, events: dayEvents, rules, learning, weekBusy: contextBusy, weekEvents: contextEvents });
    return rankCandidateSlots({ candidates: arranged, zone: host.timezone, busy: dayBusy, feedback, meetingDay: meetingMinutes >= 60 || load.meetings >= 2 });
  }).slice(0, candidateLimit);
  return { date, durationMinutes, candidates, travel: { inPersonEventCount: travel.eventCount, maximumBufferMinutes: travel.maximumBufferMinutes, routeProvider: travel.routeProvider, adviceSource: travel.adviceSource }, hostTimezone: host.timezone, hostTimezoneSource: host.source, viewerTimeZone, demo: DEMO };
}
async function availableDates(input) {
  if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(input.month || '')) throw new Error('Invalid month');
  const calendar = calendarAdapter(), settings = getSettings();
  const host = await currentHostTimeZone(calendar, settings);
  const viewerTimeZone = isValidTimeZone(input.viewerTimeZone) ? input.viewerTimeZone : host.timezone;
  const durationMinutes = Math.min(180, Math.max(15, Number(input.durationMinutes) || settings.durationMinutes));
  const today = dateKeyInZone(Date.now(), viewerTimeZone);
  const max = new Date(`${today}T12:00:00Z`); max.setUTCDate(max.getUTCDate() + 90);
  const maxDate = max.toISOString().slice(0, 10);
  const [year, month] = input.month.split('-').map(Number);
  const lastDay = new Date(Date.UTC(year, month, 0)).getUTCDate();
  const days = Array.from({ length: lastDay }, (_, index) => `${input.month}-${String(index + 1).padStart(2, '0')}`).filter(day => day >= today && day <= maxDate);
  if (!days.length) return { month: input.month, durationMinutes, viewerTimeZone, dates: [], recommendedDate: null };
  let snapshot = null;
  if (!DEMO) {
    const viewerStart = zonedEpoch(days[0], 0, viewerTimeZone), viewerEnd = zonedEpoch(days.at(-1), 24, viewerTimeZone);
    const firstHostDay = dateKeyInZone(viewerStart, host.timezone), lastHostDay = dateKeyInZone(viewerEnd - 1, host.timezone);
    const start = new Date(zonedEpoch(mondayOf(firstHostDay), 0, host.timezone)).toISOString();
    const end = new Date(zonedEpoch(shiftDay(mondayOf(lastHostDay), 12), 0, host.timezone)).toISOString();
    const [busy, events] = await Promise.all([calendar.freeBusy({ start, end }), calendar.events({ start, end, includeWorkload: true })]);
    snapshot = { settings, host, busy, events, feedback: db.slotFeedback(), rules: projectRules() };
  }
  const dates = [];
  const preferences = [];
  let partial = false;
  for (const date of days) {
    if (partial && snapshot) {
      const viewerStart = zonedEpoch(date, 0, viewerTimeZone), viewerEnd = zonedEpoch(date, 24, viewerTimeZone);
      const firstHostDay = dateKeyInZone(viewerStart, host.timezone), lastHostDay = dateKeyInZone(viewerEnd - 1, host.timezone);
      const hostStart = new Date(zonedEpoch(firstHostDay, 0, host.timezone)).toISOString();
      const hostEnd = new Date(zonedEpoch(lastHostDay, 24, host.timezone)).toISOString();
      if (snapshot.events.some(event => event.inPerson && overlaps(hostStart, hostEnd, event))) continue;
    }
    let result;
    try { result = await availability({ date, durationMinutes, viewerTimeZone }, calendar, snapshot); }
    catch (error) {
      if (error.message !== 'Google Routes failed (429)') throw error;
      partial = true;
      continue;
    }
    if (result.candidates.length) {
      dates.push(date);
      const hostDay = dateKeyInZone(result.candidates[0].start, host.timezone);
      preferences.push({ date, score: weeklyDatePreference({ day: hostDay, zone: host.timezone, hours: settings.hours, busy: snapshot?.busy || [], events: snapshot?.events || [], rules: snapshot?.rules || projectRules() }) });
    }
  }
  const recommendedDate = preferences.slice(0, 7).sort((a, b) => b.score - a.score || a.date.localeCompare(b.date))[0]?.date || null;
  return { month: input.month, durationMinutes, viewerTimeZone, dates, recommendedDate, partial };
}
const booking = new BookingService({ store: db });
const bookingLinks = new BookingLinks({ secret: encryptionSecret, publicOrigin: DEMO ? baseUrl : `https://${env.PUBLIC_HOST || 'book.jaack.me'}` });
// Demo events are held only in memory; never call Google during preview/testing.
const demoManagedEvents = new Map();
let demoProviderMutationCount = 0;
let demoAmbiguousReads = 0;
let demoFailAfterCancel = env.JEV_TEST_AMBIGUOUS_CANCEL === 'true';
let demoFailBeforeReschedule = env.JEV_TEST_FAIL_BEFORE_RESCHEDULE === 'true';
const demoExternalChangesAfterRead = new Map();
const management = new BookingManagement({ store: db, links: bookingLinks, availability: (input, options = {}) => availability(input, calendarAdapter(), null, options.verify ? 192 : 12), bufferMinutes: () => getSettings().minimumTravelBufferMinutes, calendarFor: record => DEMO ? {
  getEvent: async id => { if (demoAmbiguousReads > 0) { demoAmbiguousReads--; throw new Error('Injected readback timeout'); } const event = demoManagedEvents.get(id) || { id, etag: `demo-${record.revision}`, start: { dateTime: record.start }, end: { dateTime: record.end } }; const external = demoExternalChangesAfterRead.get(id); if (external) { demoExternalChangesAfterRead.delete(id); demoManagedEvents.set(id, external); } return event; },
  cancelEvent: async id => { demoProviderMutationCount++; demoManagedEvents.set(id, { id, status: 'cancelled' }); if (demoFailAfterCancel) { demoFailAfterCancel = false; demoAmbiguousReads = 1; throw new Error('Injected lost provider response'); } },
  rescheduleEvent: async (id, change) => { demoProviderMutationCount++; if (demoFailBeforeReschedule) { demoFailBeforeReschedule = false; throw new Error('Injected provider failure before applying reschedule'); } const existing = demoManagedEvents.get(id) || { etag: `demo-${record.revision}` }; if (existing.etag !== change.etag) { const error = new Error('Precondition failed'); error.statusCode = 412; throw error; } demoManagedEvents.set(id, { id, etag: crypto.randomUUID(), start: { dateTime: change.start }, end: { dateTime: change.end } }); }
} : google.accountCalendar(record.googleAccountId) });
async function handler(request, response) {
  const url = new URL(request.url, baseUrl);
  try {
    if (DEMO && env.JEV_TEST_MODE === 'true' && request.method === 'GET' && url.pathname === '/__test/provider-state')
      return json(response, 200, { mutationCount: demoProviderMutationCount });
    if (DEMO && env.JEV_TEST_MODE === 'true' && request.method === 'POST' && url.pathname === '/__test/owner-change-pending') {
      const input = await body(request);
      if (typeof input.requestId !== 'string' || !db.ownerChangeRequest(input.requestId)) return json(response, 404, { error: 'Owner change not found.' });
      db.markOwnerChangePendingForTest(input.requestId);
      return json(response, 200, { ok: true });
    }
    if (DEMO && env.JEV_TEST_MODE === 'true' && request.method === 'POST' && url.pathname === '/__test/external-change-after-read') {
      const input = await body(request), record = db.bookingBySourceId(String(input.sourceId || ''));
      if (!record?.eventId || typeof input.start !== 'string' || typeof input.end !== 'string' ||
          !Number.isFinite(Date.parse(input.start)) || !Number.isFinite(Date.parse(input.end))) return json(response, 400, { error: 'Invalid test event change.' });
      demoExternalChangesAfterRead.set(record.eventId, { id: record.eventId, etag: crypto.randomUUID(),
        start: { dateTime: input.start }, end: { dateTime: input.end } });
      return json(response, 200, { ok: true });
    }
    if (request.method === 'GET' && url.pathname === '/health') return json(response, 200, { ok: true, demo: DEMO, calendar: DEMO ? 'demo' : 'google' });
    if (request.method === 'GET' && url.pathname === '/api/config') {
      const accounts = google.list();
      return json(response, 200, { demo: DEMO, googleConnected: accounts.length > 0, googleAllCalendarsAuthorized: accounts.length > 0 && accounts.every(account => account.allCalendarsAuthorized), hostTimezone: getSettings().timezone });
    }
    if (url.pathname === '/api/integrations/jaack-os/bookings' || url.pathname.startsWith('/api/integrations/jaack-os/bookings/') ||
        url.pathname.startsWith('/api/integrations/jaack-os/booking-changes/')) {
      const ownerChangeStatus = /^\/api\/integrations\/jaack-os\/booking-changes\/([0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12})$/i.exec(url.pathname);
      if (ownerChangeStatus) {
        if (request.method !== 'GET') return json(response, 405, { error: 'Method not allowed' });
        if (!requireJaackOsRead(request, response)) return;
        const requestId = ownerChangeStatus[1];
        const sourceId = url.searchParams.get('sourceId') || '';
        const requestHash = url.searchParams.get('requestHash') || '';
        if (!/^[a-f0-9]{64}$/.test(sourceId) || !/^[a-f0-9]{64}$/.test(requestHash) ||
            [...url.searchParams.keys()].some(key => !['sourceId', 'requestHash'].includes(key)))
          return json(response, 400, { error: 'Exact sourceId and requestHash are required.' });
        const journal = db.ownerChangeRequest(requestId);
        if (!journal || journal.sourceId !== sourceId || journal.requestHash !== requestHash)
          return json(response, 404, { error: 'Booking change request not found.' });
        return json(response, 200, { requestId, sourceId, requestHash, state: journal.state });
      }
      const ownerChange = /^\/api\/integrations\/jaack-os\/bookings\/([a-f0-9]{64})\/change$/.exec(url.pathname);
      if (ownerChange) {
        if (request.method !== 'POST') return json(response, 405, { error: 'Method not allowed' });
        if (!requireJaackOsWrite(request, response)) return;
        const input = await body(request);
        const allowedFields = input?.action === 'cancel' ? ['action', 'revision'] : ['action', 'revision', 'start', 'end', 'date', 'viewerTimeZone'];
        if (!input || typeof input !== 'object' || Array.isArray(input) || Object.keys(input).some(key => !allowedFields.includes(key)))
          return json(response, 400, { error: 'Unexpected booking change field.' });
        if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(String(request.headers['idempotency-key'] || '')))
          return json(response, 400, { error: 'Idempotency-Key must be a UUID.' });
        const requestId = String(request.headers['idempotency-key']);
        if (!['cancel', 'reschedule'].includes(input.action) || !Number.isSafeInteger(input.revision) || input.revision < 0)
          return json(response, 400, { error: 'Provide an action and expected booking revision.' });
        const change = input.action === 'cancel' ? { action: 'cancel', revision: input.revision } : {
          action: 'reschedule', revision: input.revision, start: input.start, end: input.end,
          date: input.date, viewerTimeZone: input.viewerTimeZone,
        };
        if (input.action === 'reschedule' && (typeof change.start !== 'string' || !Number.isFinite(Date.parse(change.start)) ||
            typeof change.end !== 'string' || !Number.isFinite(Date.parse(change.end)) ||
            !/^\d{4}-\d{2}-\d{2}$/.test(String(change.date || '')) || !isValidTimeZone(change.viewerTimeZone)))
          return json(response, 400, { error: 'Reschedule requires an exact start, end, date and time zone.' });
        const sourceId = ownerChange[1];
        const requestHash = createHash('sha256').update(JSON.stringify({ sourceId, ...change })).digest('hex');
        return await operations.run(async () => {
          let reservation;
          try { reservation = db.beginOwnerChange({ requestId, sourceId, requestHash }); }
          catch (error) { return json(response, 409, { error: error.message || 'Idempotency key conflict.' }); }
          if (reservation.state === 'succeeded' || reservation.state === 'rejected')
            return json(response, reservation.state === 'succeeded' ? 200 : 409, { ...reservation.response, replayed: true });
          let record = db.bookingBySourceId(sourceId);
          if (!record) {
            const result = { error: 'Booking not found.' };
            db.finishOwnerChange(requestId, 'rejected', result);
            return json(response, 404, result);
          }
          const ownerBooking = () => db.ownerBookingById(sourceId);
          try {
            // Reconcile provider state before resuming a journal left pending by a crash.
            const loaded = await management.loadOwner(sourceId);
            let current = db.bookingBySourceId(sourceId);
            const alreadyApplied = current && (change.action === 'cancel' ? current.status === 'cancelled' :
              current.status === 'confirmed' && Date.parse(current.start) === Date.parse(change.start) && Date.parse(current.end) === Date.parse(change.end));
            if (alreadyApplied) {
              if (reservation.replayed) {
                const result = { booking: ownerBooking() };
                db.finishOwnerChange(requestId, 'succeeded', result);
                return json(response, 200, { ...result, replayed: true });
              }
              const result = { error: 'This booking already reflects that change. Reload it before creating a new request.' };
              db.finishOwnerChange(requestId, 'rejected', result);
              return json(response, 409, result);
            }
            if (current?.pendingChange) {
              if (!reservation.replayed) {
                const result = { error: 'A booking change is already awaiting confirmation.' };
                db.finishOwnerChange(requestId, 'rejected', result);
                return json(response, 409, result);
              }
              const pending = current.pendingChange;
              const matches = pending.action === change.action && current.revision === change.revision &&
                (change.action === 'cancel' || (Date.parse(pending.start) === Date.parse(change.start) && Date.parse(pending.end) === Date.parse(change.end)));
              if (!matches) {
                const result = { error: 'A different booking change is awaiting confirmation.' };
                db.finishOwnerChange(requestId, 'rejected', result);
                return json(response, 409, result);
              }
            } else if (current?.revision !== change.revision) {
              const result = { error: 'This booking changed. Reload it before trying again.' };
              db.finishOwnerChange(requestId, 'rejected', result);
              return json(response, 409, result);
            }
            if (current?.status !== 'confirmed') {
              const result = { error: 'This booking is no longer mutable.' };
              db.finishOwnerChange(requestId, 'rejected', result);
              return json(response, 409, result);
            }
            record = db.bookingBySourceId(sourceId);
            await management.applyChange(loaded, record?.pendingChange ? { action: 'retry' } : change);
            const result = { booking: ownerBooking() };
            db.finishOwnerChange(requestId, 'succeeded', result);
            return json(response, 200, { ...result, replayed: reservation.replayed });
          } catch (error) {
            const current = db.bookingBySourceId(sourceId);
            const uncertain = Boolean(current?.pendingChange);
            const result = { error: error.message || 'Booking change failed.', ...(uncertain ? {
              state: 'uncertain', pendingAction: ownerBooking()?.pendingAction ?? null,
            } : {}) };
            db.finishOwnerChange(requestId, uncertain ? 'uncertain' : 'rejected', result);
            return json(response, uncertain ? 503 : 409, result);
          }
        });
      }
      if (!requireJaackOsRead(request, response)) return;
      if (request.method !== 'GET') return json(response, 405, { error: 'Method not allowed' });
      if (url.pathname === '/api/integrations/jaack-os/bookings') {
        const limit = url.searchParams.has('limit') ? Number(url.searchParams.get('limit')) : 50;
        const offset = url.searchParams.has('offset') ? Number(url.searchParams.get('offset')) : 0;
        if (!Number.isInteger(limit) || limit < 1 || limit > 100 || !Number.isInteger(offset) || offset < 0 || offset > 10_000) return json(response, 400, { error: 'Invalid pagination' });
        return json(response, 200, { ...db.listOwnerBookings({ limit, offset }), limit, offset });
      }
      const id = url.pathname.slice('/api/integrations/jaack-os/bookings/'.length);
      if (!/^[a-f0-9]{64}$/.test(id)) return json(response, 404, { error: 'Booking not found' });
      const booking = db.ownerBookingById(id);
      return booking ? json(response, 200, { booking }) : json(response, 404, { error: 'Booking not found' });
    }
    if (url.pathname === '/api/google/accounts') {
      if (!requireOwner(request, response)) return;
      if (request.method === 'GET') return json(response, 200, { accounts: google.list(), demo: DEMO });
      if (!ownerMutation(request, response)) return;
      const input = await body(request);
      if (request.method === 'DELETE' || request.method === 'PUT') {
        await operations.run(() => request.method === 'DELETE' ? db.disconnectGoogle(String(input.accountId || '')) : db.selectGoogle(String(input.accountId || '')));
        return json(response, 200, { accounts: google.list(), demo: DEMO });
      }
    }
    if (request.method === 'POST' && url.pathname === '/api/google/connect') {
      if (!ownerMutation(request, response)) return;
      if (DEMO) throw new Error('Demo mode has no Google OAuth');
      const input = await body(request);
      const flow = google.begin({ intent: input.accountId ? 'reconnect' : 'add', accountId: input.accountId, session: cookies(request).jev_session });
      setCookie(response, 'jev_oauth', flow.nonce, { maxAge: 600 });
      return json(response, 200, { url: flow.url });
    }
    if (request.method === 'GET' && url.pathname === '/api/settings') { if (!requireOwner(request, response)) return; const s = getSettings(); return json(response, 200, { ...s, baseLocation: owner(request) ? s.baseLocation : undefined }); }
    if (request.method === 'GET' && url.pathname === '/api/workload') {
      if (!requireOwner(request, response)) return;
      const calendar = calendarAdapter(), rules = projectRules(), settings = getSettings();
      const learning = currentLearning(settings, rules, settings.timezone);
      return json(response, 200, { rules, calendars: await calendar.workloadCalendars(), learning: learning && { updatedAt: learning.updatedAt, baselineBusyMinutes: learning.baselineBusyMinutes, typicalProjectMinutes: learning.typicalProjectMinutes, bookingNotice: learning.bookingNotice, weekAlert: learning.weekAlert || null } });
    }
    if (request.method === 'PUT' && url.pathname === '/api/workload') {
      if (!ownerMutation(request, response)) return;
      const rules = normalizeProjectRules((await body(request)).rules);
      db.putSetting('projectRules', rules);
      void refreshWorkloadIfDue();
      return json(response, 200, { ok: true, rules });
    }
    if (request.method === 'POST' && url.pathname === '/api/workload/refresh') {
      if (!ownerMutation(request, response)) return;
      const learning = await refreshWorkload();
      return json(response, 200, { ok: true, updatedAt: learning?.updatedAt || null });
    }
    if (request.method === 'POST' && url.pathname === '/api/address-search') {
      if (!requireOwner(request, response)) return;
      const incoming = await body(request);
      const suggestions = (await addressSearch.autocomplete({ input: incoming.input, languageCode: incoming.languageCode })).map((suggestion) => ({ text: suggestion.text, mainText: suggestion.mainText, secondaryText: suggestion.secondaryText, selectionToken: addressSelections.encode(suggestion) }));
      return json(response, 200, { suggestions, provider: 'photon' });
    }
    if (request.method === 'PUT' && url.pathname === '/api/settings') {
      if (!requireOwner(request, response)) return;
      const incoming = await body(request), current = getSettings();
      const requestedLocation = String(incoming.baseLocation || '').trim().slice(0, 300);
      let verifiedLocation = { formattedAddress: '', provider: '', providerId: '', location: null };
      if (requestedLocation) {
        const sameVerifiedLocation = incoming.baseLocationProviderId && incoming.baseLocationProviderId === current.baseLocationProviderId && requestedLocation === current.baseLocation;
        verifiedLocation = sameVerifiedLocation ? { formattedAddress: current.baseLocation, provider: current.baseLocationProvider, providerId: current.baseLocationProviderId, location: current.baseLocationCoordinates || null } : addressSelections.decode(incoming.addressSelectionToken);
        if (requestedLocation !== verifiedLocation.formattedAddress) throw new Error('Choose an address from the search results');
      }
      const notice = incoming.minimumBookingNoticeMinutes === undefined ? current.minimumBookingNoticeMinutes : incoming.minimumBookingNoticeMinutes;
      if (!Number.isInteger(notice) || notice < 0 || notice > 10_080) throw new Error('Advance notice must be between 0 and 168 hours');
      const settings = { ...current, hours: { start: Math.max(0, Math.min(23, Number(incoming.hours?.start) || 9)), end: Math.max(1, Math.min(24, Number(incoming.hours?.end) || 18)) }, durationMinutes: Math.max(15, Math.min(180, Number(incoming.durationMinutes) || 30)), baseLocation: verifiedLocation.formattedAddress, baseLocationProvider: verifiedLocation.provider, baseLocationProviderId: verifiedLocation.providerId, baseLocationCoordinates: verifiedLocation.location, minimumTravelBufferMinutes: Math.max(0, Math.min(60, Number(incoming.minimumTravelBufferMinutes) || 10)), minimumBookingNoticeMinutes: notice };
      if (settings.hours.end <= settings.hours.start) throw new Error('End hour must be after start hour'); db.putSetting('settings', settings); void refreshWorkloadIfDue(); return json(response, 200, { ok: true, settings });
    }
    if (request.method === 'PUT' && url.pathname === '/api/timezone') { if (!requireOwner(request, response)) return; const incoming = await body(request); if (!isValidTimeZone(incoming.timezone)) throw new Error('Invalid time zone'); const settings = { ...getSettings(), timezone: incoming.timezone, timezoneSource: 'owner-device', timezoneUpdatedAt: new Date().toISOString() }; db.putSetting('settings', settings); void refreshWorkloadIfDue(); return json(response, 200, { ok: true, timezone: settings.timezone, source: settings.timezoneSource, updatedAt: settings.timezoneUpdatedAt }); }
    if (request.method === 'POST' && url.pathname === '/api/availability') return json(response, 200, await availability(await body(request)));
    if (request.method === 'POST' && url.pathname === '/api/available-dates') return json(response, 200, await availableDates(await body(request)));
    if (request.method === 'POST' && ['/api/booking/view', '/api/booking/slots', '/api/booking/change'].includes(url.pathname)) {
      const input = await body(request);
      return await operations.run(async () => {
        const result = url.pathname === '/api/booking/view' ? await management.view(input.token) : url.pathname === '/api/booking/slots' ? await management.slots(input.token, input) : await management.change(input.token, input);
        return json(response, 200, result);
      });
    }
    if (request.method === 'POST' && url.pathname === '/api/book') {
      const input = await body(request);
      return await operations.run(async () => {
        if (typeof input.idempotencyKey !== 'string' || input.idempotencyKey.length > 256) throw new Error('Invalid booking request');
        const calendar = calendarAdapter();
        const start = String(input.start || ''), end = String(input.end || '');
        if (hardConstraint({ start, end, busy: [], bufferMinutes: 0 })) throw new Error('Invalid booking request');
        const prior = db.get(input.idempotencyKey);
        const bookingInput = { start, end, bufferMinutes: getSettings().minimumTravelBufferMinutes, idempotencyKey: input.idempotencyKey, guestName: String(input.guestName || '').slice(0, 120), guestEmail: String(input.guestEmail || '').slice(0, 254), meetingTitle: input.meetingTitle, managementLinks: bookingLinks.urls(input.idempotencyKey), googleAccountId: prior?.googleAccountId ?? (DEMO ? null : db.getSetting('googleBookingAccountId', null)) };
        const sendBooking = (result, status) => {
          const { googleAccountId, pendingChange, ...publicBooking } = result;
          publicBooking.managementUrl = bookingLinks.urls(result.idempotencyKey).view;
          return json(response, status, { booking: publicBooking, demo: DEMO });
        };
        if (prior?.status === 'confirmed') return sendBooking(await booking.book(bookingInput, calendar), 200);
        const viewerTimeZone = isValidTimeZone(input.viewerTimeZone) ? input.viewerTimeZone : getSettings().timezone;
        const fresh = await availability({ date: /^\d{4}-\d{2}-\d{2}$/.test(input.date) ? input.date : dateKeyInZone(start, viewerTimeZone), viewerTimeZone, durationMinutes: input.durationMinutes }, calendar, null, 192);
        if (!fresh.candidates.some((slot) => slot.start === start && slot.end === end)) throw new Error('That slot is no longer available');
        const settings = getSettings();
        if (Date.parse(start) < Date.now() + effectiveNoticeMinutes(settings, currentLearning(settings, projectRules(), settings.timezone)) * 60_000) throw new Error('That slot is too soon to book');
        return sendBooking(await booking.book(bookingInput, calendar), 201);
      });
    }
    if (request.method === 'GET' && url.pathname === '/auth/google') {
      if (DEMO) throw new Error('Demo mode has no Google OAuth');
      const flow = google.begin({ intent: 'login' });
      setCookie(response, 'jev_oauth', flow.nonce, { maxAge: 600 });
      response.writeHead(302, { Location: flow.url, 'Cache-Control': 'no-store' }); return response.end();
    }
    if (request.method === 'GET' && url.pathname === '/auth/google/callback') {
      try {
        const result = await operations.run(() => google.finish({ state: url.searchParams.get('state'), cookieNonce: cookies(request).jev_oauth, code: url.searchParams.get('code'), session: cookies(request).jev_session }));
        if (result.login) setCookie(response, 'jev_session', db.newSession(), { maxAge: 28800 });
        response.writeHead(302, { Location: '/owner', 'Cache-Control': 'no-store' }); return response.end();
      } catch (error) {
        if (!owner(request)) throw error;
        response.writeHead(302, { Location: `/owner?connectionError=${encodeURIComponent(error.message)}`, 'Cache-Control': 'no-store' }); return response.end();
      }
    }
    if (request.method === 'GET' && url.pathname === '/owner') {
      if (!owner(request)) { response.writeHead(302, { Location: '/auth/google', 'Cache-Control': 'no-store' }); return response.end(); }
      return serve(response, 'owner.html');
    }
    if (request.method === 'GET' && url.pathname === '/manage') return serve(response, 'manage.html');
    if (request.method === 'GET' && url.pathname === '/privacy') return serve(response, 'privacy.html');
    if (request.method === 'GET' && url.pathname === '/') return serve(response, 'index.html');
    if (request.method === 'GET' && url.pathname.startsWith('/assets/')) return serve(response, url.pathname.slice(1));
    json(response, 404, { error: 'Not found' });
  } catch (error) { json(response, 400, { error: error.message || 'Request failed' }); }
}
async function serve(response, file) { const clean = resolve('./public', file); if (!clean.startsWith(resolve('./public'))) return json(response, 403, { error: 'Forbidden' }); const data = await readFile(clean); response.writeHead(200, { 'Content-Type': mime[extname(clean)] || 'application/octet-stream', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' }); response.end(data); }
http.createServer(handler).listen(port, '127.0.0.1', () => console.log(`Jev Calendar listening at ${baseUrl} (${DEMO ? 'demo' : 'Google'})`));
if (!DEMO) {
  void refreshWorkloadIfDue();
  setInterval(() => { void refreshWorkloadIfDue(); }, 60 * 60_000).unref();
}

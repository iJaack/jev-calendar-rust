import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { runInNewContext } from 'node:vm';

const source = readFileSync(new URL('../public/assets/public.js', import.meta.url), 'utf8');

// Minimal DOM fixture for executing the actual page script and its event handlers.
function element() {
  const classes = new Set();
  return {
    children: [], dataset: {}, attributes: {}, listeners: {}, textContent: '',
    classList: { add: (x) => classes.add(x), remove: (x) => classes.delete(x), contains: (x) => classes.has(x), toggle: (x, on) => on ? classes.add(x) : classes.delete(x) },
    setAttribute(key, value) { this.attributes[key] = value; },
    addEventListener(type, callback) { this.listeners[type] = callback; },
    append(...nodes) { this.children.push(...nodes); },
    replaceChildren(...nodes) { this.children = nodes; },
    set innerHTML(value) { this.children = []; this.html = value; },
  };
}
function page() {
  const elements = new Map();
  const get = (id) => { if (!elements.has(id)) elements.set(id, element()); return elements.get(id); };
  const durations = [30, 45, 60].map(value => { const button = element(); button.dataset.duration = String(value); return button; });
  const pending = [];
  const now = Date.parse('2026-09-21T23:30:00Z');
  class FixedDate extends Date {
    constructor(...args) { super(...(args.length ? args : [now])); }
    static now() { return now; }
  }
  runInNewContext(source, {
    Date: FixedDate, Intl,
    document: { getElementById: get, createElement: element, querySelectorAll: selector => selector === '.duration-option' ? durations : [] },
    fetch: (path, options) => {
      if (path === '/api/config') return Promise.resolve({ json: async () => ({}) });
      return new Promise((resolve, reject) => pending.push({ path, input: JSON.parse(options.body), resolve, reject }));
    },
  });
  const settle = async (index, data = {}, error) => {
    const item = pending[index];
    if (error) item.reject(new Error(error));
    else item.resolve({ ok: true, json: async () => item.path === '/api/available-dates'
      ? { dates: [], ...data }
      : { candidates: [], hostTimezone: 'Europe/Rome', viewerTimeZone: item.input.viewerTimeZone, demo: false, ...data } });
    await new Promise(setImmediate);
  };
  const day = (date) => get('calendar-grid').children.find(x => x.dataset.date === date);
  return { get, pending, settle, day, durations, now };
}

test('calendar enables only dates with slots, then loads the first available day', async () => {
  const p = page();
  const zone = Intl.DateTimeFormat().resolvedOptions().timeZone;
  const parts = Object.fromEntries(new Intl.DateTimeFormat('en-CA', { timeZone: zone, year: 'numeric', month: '2-digit', day: '2-digit' }).formatToParts(p.now).map(x => [x.type, x.value]));
  const today = `${parts.year}-${parts.month}-${parts.day}`;
  assert.equal(p.pending[0].path, '/api/available-dates');
  assert.equal(p.pending[0].input.month, '2026-09');
  assert.equal(p.pending[0].input.viewerTimeZone, zone);
  assert.equal(p.day(today).disabled, true);
  await p.settle(0, { dates: [today] });
  assert.equal(p.day(today).disabled, false);
  assert.equal(p.day('2026-09-25').disabled, true);
  assert.match(p.day('2026-09-25').attributes['aria-label'], /no available times/);
  assert.equal(p.day(today).attributes['aria-current'], 'date');
  assert.equal(p.pending[1].path, '/api/availability');
  assert.equal(p.pending[1].input.date, today);
  await p.settle(1, { candidates: [{ start: `${today}T12:00:00Z` }] });
  assert.equal(p.get('slots').children[0].className, 'time-choice');
});

test('slot labels use the offset on the meeting date across daylight saving time', async () => {
  const p = page();
  const selector = p.get('viewer-timezone');
  selector.value = 'America/New_York';
  selector.listeners.change();
  await p.settle(1, { dates: ['2026-11-02'] });
  await p.settle(2, { candidates: [{ start: '2026-11-02T15:00:00.000Z', end: '2026-11-02T15:30:00.000Z' }] });
  assert.match(p.get('slots').children[0].children[0].textContent, /10:00 AM EST/);
  assert.equal(selector.children.find(option => option.value === 'America/New_York').textContent, 'America/New York');
});

test('calendar highlights and opens the suggested date while retaining every bookable date', async () => {
  const p = page();
  await p.settle(0, { dates: ['2026-09-24', '2026-09-25'], recommendedDate: '2026-09-25' });
  assert.equal(p.day('2026-09-24').disabled, false);
  assert.equal(p.day('2026-09-25').classList.contains('recommended'), true);
  assert.match(p.day('2026-09-25').attributes['aria-label'], /suggested date/);
  assert.equal(p.pending[1].input.date, '2026-09-25');
});

test('a date that becomes empty is disabled after the live day check', async () => {
  const p = page();
  await p.settle(0, { dates: ['2026-09-24', '2026-09-25'] });
  await p.settle(1);
  assert.equal(p.day('2026-09-24').disabled, true);
  assert.equal(p.day('2026-09-25').disabled, false);
});

test('a partial month keeps safe dates available and explains missing travel checks', async () => {
  const p = page();
  await p.settle(0, { dates: ['2026-09-24'], partial: true });
  await p.settle(1, { candidates: [{ start: '2026-09-24T12:00:00Z', end: '2026-09-24T12:30:00Z' }] });
  assert.equal(p.day('2026-09-24').disabled, false);
  assert.match(p.get('availability-status').textContent, /travel routing is limited/);
});

test('month navigation ignores a stale availability summary', async () => {
  const p = page();
  p.get('next-month').listeners.click();
  assert.equal(p.pending[1].input.month, '2026-10');
  await p.settle(1, { dates: ['2026-10-05'] });
  assert.equal(p.day('2026-10-05').disabled, false);
  await p.settle(0, { dates: ['2026-09-24'] });
  assert.equal(p.get('month-label').textContent, 'October 2026');
  assert.equal(p.day('2026-10-05').disabled, false);
});

test('duration changes recheck dates and disable days that no longer have slots', async () => {
  const p = page();
  await p.settle(0, { dates: ['2026-09-24'] });
  await p.settle(1, { candidates: [{ start: '2026-09-24T12:00:00Z' }] });
  assert.equal(p.day('2026-09-24').disabled, false);
  p.durations[1].listeners.click();
  assert.equal(p.pending[2].input.durationMinutes, 45);
  assert.equal(p.day('2026-09-24').disabled, true);
  await p.settle(2, { dates: [] });
  assert.equal(p.day('2026-09-24').disabled, true);
  assert.equal(p.get('retry-dates').classList.contains('hidden'), false);
});

test('failed month check keeps dates disabled and offers a retry', async () => {
  const p = page();
  await p.settle(0, {}, 'Calendar unavailable');
  assert.equal(p.day('2026-09-24').disabled, true);
  assert.equal(p.get('retry-dates').classList.contains('hidden'), false);
  p.get('retry-dates').listeners.click();
  await p.settle(1, { dates: ['2026-09-24'] });
  assert.equal(p.day('2026-09-24').disabled, false);
});

for (const staleError of [false, true]) {
  test(`a stale day ${staleError ? 'error' : 'response'} cannot replace a newer date`, async () => {
    const p = page();
    await p.settle(0, { dates: ['2026-09-24', '2026-09-25'] });
    p.day('2026-09-25').listeners.click();
    await p.settle(2, { candidates: [{ start: '2026-09-25T12:00:00Z' }] });
    const rendered = p.get('slots').children[0];
    await p.settle(1, {}, staleError ? 'Old request failed' : undefined);
    assert.equal(p.get('slots').children[0], rendered);
    assert.equal(p.get('slots').children[0].className, 'time-choice');
  });
}

import test from 'node:test';
import assert from 'node:assert/strict';
import { SqliteStore } from '../lib/store.js';
import { BookingLinks, BookingManagement } from '../lib/booking-management.js';
import { GoogleCalendarAdapter } from '../lib/calendar.js';
import { BookingService } from '../lib/booking.js';
const old = {start:'2030-10-07T09:00:00.000Z',end:'2030-10-07T09:30:00.000Z'};
const next = {start:'2030-10-08T09:00:00.000Z',end:'2030-10-08T09:30:00.000Z'};
function fixture(t) {
  const store = new SqliteStore({path:':memory:',encryptionSecret:'test'}); t.after(()=>store.db.close());
  const links = new BookingLinks({secret:'test',publicOrigin:'https://book.test'});
  store.reserve({...old,idempotencyKey:'original-booking',bufferMinutes:10,googleAccountId:'original-owner',meetingTitle:'Project planning'});
  store.confirm('original-booking',{id:'original-event',meetLink:'https://meet.google.com/test'});
  let remote={id:'original-event',etag:'v1',start:{dateTime:old.start},end:{dateTime:old.end}};
  let allowed=true;const calls=[];
  const calendar={getEvent:async()=>remote,cancelEvent:async(id,etag)=>{assert.equal(etag,remote.etag);calls.push(['cancel',id]);remote=null;},rescheduleEvent:async(id,input)=>{assert.equal(input.etag,remote.etag);calls.push(['move',id]);remote={...remote,etag:'v2',start:{dateTime:input.start},end:{dateTime:input.end}};return remote;}};
  const manager = new BookingManagement({store,links,clock:()=>Date.parse('2030-10-01'),bufferMinutes:()=>20,calendarFor:record=>{assert.equal(record.googleAccountId,'original-owner');return calendar;},availability:async()=>({candidates:allowed?[next]:[]})});
  return {store,links,manager,calendar,calls,token:links.token('original-booking'),block:()=>{allowed=false;},setRemote:value=>{remote=value;}};
}
test('signed management links resist tampering and keep their token out of the path/query',()=>{
  const links = new BookingLinks({secret:'test',publicOrigin:'https://book.test'});
  const urls=links.urls('booking-key');
  for(const action of ['cancel','reschedule']) {const url=new URL(urls[action]);assert.equal(url.pathname,'/manage');assert.equal(url.search,'');const params=new URLSearchParams(url.hash.slice(1));assert.equal(params.get('action'),action);assert.equal(links.key(params.get('token')),'booking-key');}
  for(const token of ['',null,'invalid','a.b','a.'.padEnd(3000,'a'),links.token('booking-key')+'x']) assert.throws(()=>links.key(token),/invalid/);
  assert.throws(()=>new BookingLinks({secret:'different',publicOrigin:'https://book.test'}).key(links.token('booking-key')),/invalid/);
});
test('viewing a link is read-only and returns no guest identity, account or event ID',async t=>{
  const f=fixture(t),view=await f.manager.view(f.token);
  assert.equal(view.meetingTitle,'Project planning');assert.deepEqual(f.calls,[]);
  assert.ok(!JSON.stringify(view).includes('original-owner'));assert.equal(view.eventId,undefined);assert.equal(view.guestEmail,undefined);
  await assert.rejects(f.manager.view(f.links.token('missing-key')),/no longer available/);
});
test('reschedule checks availability, moves the same event/account, preserves Meet and rejects stale tabs',async t=>{
  const f=fixture(t);
  const result=await f.manager.change(f.token,{action:'reschedule',revision:0,...next,date:'2030-10-08',viewerTimeZone:'UTC'});
  assert.equal(result.start,next.start);assert.equal(result.revision,1);assert.equal(result.meetLink,'https://meet.google.com/test');assert.deepEqual(f.calls,[['move','original-event']]);
  assert.equal(f.store.get('original-booking').bufferMinutes,20);
  assert.deepEqual(f.store.slotFeedback().map(item => item.outcome).sort(), ['confirmed', 'rescheduled']);
  assert.equal(f.store.slotFeedback().find(item => item.outcome === 'rescheduled').start, old.start);
  await assert.rejects(f.manager.change(f.token,{action:'cancel',revision:0}),/changed/);
  assert.equal(f.calls.length,1);
});
test('busy reschedule leaves original booking and event intact',async t=>{
  const f=fixture(t);f.block();
  await assert.rejects(f.manager.change(f.token,{action:'reschedule',revision:0,...next}),/no longer available/);
  assert.equal(f.store.get('original-booking').start,old.start);assert.deepEqual(f.calls,[]);
  await assert.rejects(f.manager.change(f.token,{action:'reschedule',revision:0,...next,end:'2030-10-08T10:00:00Z'}),/original meeting length/);
});
test('local reservations and pending moves also prevent conflicting bookings',async t=>{
  const f=fixture(t);
  f.store.beginChange('original-booking',0,{action:'reschedule',...next,bufferMinutes:20,etag:'v1'});
  for(const slot of [old,next]) assert.throws(()=>f.store.reserve({...slot,idempotencyKey:`new-${slot.start}`,bufferMinutes:10}),/conflict/);
  f.store.clearChange('original-booking');
  f.store.reserve({...next,idempotencyKey:'other-booking',bufferMinutes:10});
  await assert.rejects(f.manager.change(f.token,{action:'reschedule',revision:0,...next}),/conflict/);
  assert.deepEqual(f.calls,[]);
});
test('cancel is idempotent, releases the slot and cannot be replayed as a new booking',async t=>{
  const f=fixture(t);
  assert.equal((await f.manager.change(f.token,{action:'cancel',revision:0})).status,'cancelled');
  assert.equal((await f.manager.change(f.token,{action:'cancel',revision:0})).status,'cancelled');
  assert.equal(f.calls.length,1);assert.equal((await f.manager.view(f.token)).meetLink,null);
  assert.deepEqual(f.store.slotFeedback().map(item => item.outcome), ['cancelled']);
  f.store.reserve({...old,idempotencyKey:'replacement',bufferMinutes:10});
  await assert.rejects(new BookingService({store:f.store}).book({...old,bufferMinutes:10,idempotencyKey:'original-booking'}),/cancelled/);
});
test('a lost successful Google response is reconciled without issuing a second update',async t=>{
  const f=fixture(t),original=f.calendar.rescheduleEvent;
  f.calendar.rescheduleEvent=async(...args)=>{await original(...args);throw new Error('network lost');};
  const result=await f.manager.change(f.token,{action:'reschedule',revision:0,...next});
  assert.equal(result.start,next.start);assert.equal(f.calls.length,1);assert.equal(f.store.get('original-booking').pendingChange,null);
});
test('uncertain errors keep durable intent; explicit retry uses the same event and precondition',async t=>{
  const f=fixture(t),original=f.calendar.rescheduleEvent;
  f.calendar.rescheduleEvent=async()=>{throw new Error('network lost');};
  await assert.rejects(f.manager.change(f.token,{action:'reschedule',revision:0,...next}),/could not be confirmed/);
  assert.equal(f.store.get('original-booking').pendingChange.action,'reschedule');
  assert.equal((await f.manager.view(f.token)).pendingAction,'reschedule');assert.equal(f.calls.length,0);
  f.calendar.rescheduleEvent=original;
  const result=await f.manager.change(f.token,{action:'retry'});
  assert.equal(result.start,next.start);assert.equal(f.calls.length,1);
});
test('definite Google rejection keeps the old meeting; external edits invalidate old revision',async t=>{
  const f=fixture(t);
  f.calendar.cancelEvent=async()=>{throw Object.assign(new Error('forbidden'),{statusCode:403});};
  await assert.rejects(f.manager.change(f.token,{action:'cancel',revision:0}),/could not accept/);
  assert.equal(f.store.get('original-booking').status,'confirmed');assert.equal(f.store.get('original-booking').pendingChange,null);
  f.setRemote({etag:'manual',start:{dateTime:next.start},end:{dateTime:next.end}});
  const result=await f.manager.view(f.token);assert.equal(result.start,next.start);assert.equal(result.revision,1);
  await assert.rejects(f.manager.change(f.token,{action:'cancel',revision:0}),/changed/);
});
test('started meetings cannot be changed and disconnected original accounts fail safely',async t=>{
  const f=fixture(t);f.manager.clock=()=>Date.parse(old.start)+1;
  await assert.rejects(f.manager.change(f.token,{action:'cancel',revision:0}),/already started/);
  f.manager.clock=()=>Date.parse('2030-10-01');f.manager.calendarFor=()=>{throw new Error('calendar disconnected');};
  await assert.rejects(f.manager.change(f.token,{action:'cancel',revision:0}),/disconnected/);assert.deepEqual(f.calls,[]);
});
test('Google payload includes management links; move preserves all other fields and sends attendee updates',async()=>{
  const calls=[];const calendar=new GoogleCalendarAdapter({tokenProvider:{accessToken:async()=> 'test'},fetchImpl:async(url,init)=>{calls.push({url,init});return init.method==='DELETE'?new Response(null,{status:204}):new Response(JSON.stringify({id:'event',etag:'v1'}));}});
  const links=new BookingLinks({secret:'test',publicOrigin:'https://book.test'}).urls('booking-key');
  await calendar.createEvent({...old,managementLinks:links});
  const payload=JSON.parse(calls[0].init.body);assert.ok(payload.description.includes(links.cancel));assert.ok(payload.description.includes(links.reschedule));
  await calendar.rescheduleEvent('event/with/slash',{...next,etag:'v1'});
  assert.deepEqual(JSON.parse(calls[1].init.body),{start:{dateTime:next.start},end:{dateTime:next.end}});
  assert.equal(calls[1].init.headers['If-Match'],'v1');assert.ok(calls[1].url.includes('sendUpdates=all'));assert.ok(calls[1].url.includes('event%2Fwith%2Fslash'));
  await calendar.cancelEvent('event','v2');assert.equal(calls[2].init.method,'DELETE');assert.equal(calls[2].init.headers['If-Match'],'v2');assert.ok(calls[2].url.includes('sendUpdates=all'));
});

import test from 'node:test';
import assert from 'node:assert/strict';
import { arrangeWorkloadSlots, dayWorkload, deadlineStage, learnWorkload, normalizeProjectRules, projectForEvent, rankCandidateSlots, weeklyDatePreference, weeklyWorkloadAlert } from '../lib/workload.js';

const hours = { start: 9, end: 18 };
const zone = 'UTC';
const day = '2026-10-05';
const interval = (start, end) => ({ start: `${day}T${start}:00.000Z`, end: `${day}T${end}:00.000Z` });
const slots = ['09:00', '10:00', '15:00', '16:00'].map(start => interval(start, `${String(Number(start.slice(0, 2)) + 1).padStart(2, '0')}:00`));

test('project rules match title keywords before calendars and keep unmatched events unassigned', () => {
  const rules = normalizeProjectRules([
    { name: 'Team1', type: 'meetings', keywords: ['Team1'], calendarIds: ['shared'] },
    { name: 'GM10', type: 'focus', keywords: ['Gem Mint', 'GM10'], calendarIds: [] }
  ]);
  assert.equal(projectForEvent({ summary: 'GM10 build review', calendarId: 'shared' }, rules).name, 'GM10');
  assert.equal(projectForEvent({ summary: 'Planning', calendarId: 'shared' }, rules).name, 'Team1');
  assert.equal(projectForEvent({ summary: 'Team1 update', calendarName: 'Personal' }, rules).name, 'Team1');
  assert.equal(projectForEvent({ summary: 'Private', calendarName: 'Personal' }, rules), null);
  assert.throws(() => normalizeProjectRules([{ name: 'A', type: 'unknown' }]), /workload type/);
});

test('daily workload unions overlapping calendars and learns a project baseline without titles', () => {
  const rules = normalizeProjectRules([{ name: 'Team1', type: 'meetings', keywords: ['Team1'], calendarIds: [] }]);
  const busy = [interval('10:00', '12:00'), interval('11:00', '13:00')];
  const events = [{ ...interval('10:00', '12:00'), summary: 'Team1 private event' }];
  const current = dayWorkload({ day, zone, hours, busy, events, rules });
  assert.equal(current.busyMinutes, 180);
  assert.equal(current.projects.Team1.minutes, 120);
  assert.equal(current.projects.Team1.typeMinutes.meetings, 120);
  const learned = learnWorkload({ startDay: day, days: 1, zone, hours, busy, events, rules });
  assert.equal(learned.baselineBusyMinutes, 180);
  assert.equal(learned.typicalProjectMinutes.Team1, 120);
  assert.equal(JSON.stringify(learned).includes('private event'), false);
});

test('an explicit title workload type overrides the project default without changing its project', () => {
  const rules = normalizeProjectRules([{ name: 'Team1', type: 'meetings', keywords: ['Team1'], calendarIds: [] }]);
  const work = dayWorkload({ day, zone, hours, busy: [interval('10:00', '12:00')], events: [{ ...interval('10:00', '12:00'), summary: 'Team1 [focus] article' }], rules });
  assert.equal(work.projects.Team1.minutes, 120);
  assert.equal(work.projects.Team1.typeMinutes.focus, 120);
  assert.equal(work.projects.Team1.typeMinutes.meetings, 0);
});

test('heavy meeting days cluster slots, focus days preserve the middle, and deadline days close', () => {
  const busy = [interval('11:00', '14:00')];
  const learning = { baselineBusyMinutes: 120, typicalProjectMinutes: { Work: 90 } };
  const run = (type) => arrangeWorkloadSlots({ day, candidates: slots, zone, hours, busy, events: [{ ...interval('11:00', '14:00'), summary: 'Work' }], rules: [{ name: 'Work', type, keywords: ['Work'], calendarIds: [] }], learning });
  assert.deepEqual(run('meetings').map(slot => slot.start.slice(11, 16)), ['09:00', '10:00']);
  assert.deepEqual(run('focus').map(slot => slot.start.slice(11, 16)), ['09:00', '16:00']);
  assert.deepEqual(run('deadline'), []);
  assert.equal(arrangeWorkloadSlots({ day, candidates: slots, zone, hours, busy: [interval('11:00', '12:00')], events: [], rules: [], learning }).length, slots.length);
});

test('week-wide focus protection moves new calls toward an existing meeting day', () => {
  const monday = '2026-10-05', tuesday = '2026-10-06';
  const meeting = { start: `${monday}T11:00:00Z`, end: `${monday}T13:00:00Z`, summary: 'Team1 call' };
  const rules = [{ name: 'Team1', type: 'meetings', keywords: ['Team1'], calendarIds: [] }];
  const tuesdaySlots = ['09:00', '10:00', '15:00', '16:00'].map(start => ({ start: `${tuesday}T${start}:00Z`, end: `${tuesday}T${String(Number(start.slice(0, 2)) + 1).padStart(2, '0')}:00:00Z` }));
  const arranged = arrangeWorkloadSlots({ day: tuesday, candidates: tuesdaySlots, zone, hours, busy: [], events: [], rules, learning: null, weekBusy: [meeting], weekEvents: [meeting] });
  assert.deepEqual(arranged.map(slot => slot.start.slice(11, 16)), ['09:00', '16:00']);
  assert.ok(weeklyDatePreference({ day: monday, zone, hours, busy: [meeting], events: [meeting], rules }) > weeklyDatePreference({ day: tuesday, zone, hours, busy: [meeting], events: [meeting], rules }));
});

test('deadline ramps down two workdays before and reopens after the deadline', () => {
  const deadline = { start: '2026-10-12T12:00:00Z', end: '2026-10-12T12:30:00Z', summary: 'Launch [deadline]' };
  const input = { zone, events: [deadline], rules: [] };
  assert.equal(deadlineStage({ day: '2026-10-08', ...input }), 2);
  assert.equal(deadlineStage({ day: '2026-10-09', ...input }), 1);
  assert.equal(deadlineStage({ day: '2026-10-12', ...input }), 0);
  assert.equal(deadlineStage({ day: '2026-10-13', ...input }), null);
  const run = day => arrangeWorkloadSlots({ day, candidates: ['09:00', '10:00', '15:00', '16:00'].map(start => ({ start: `${day}T${start}:00Z`, end: `${day}T${String(Number(start.slice(0, 2)) + 1).padStart(2, '0')}:00:00Z` })), zone, hours, busy: [], events: [], rules: [], learning: null, weekEvents: [deadline] });
  assert.equal(run('2026-10-08').length, 2);
  assert.equal(run('2026-10-09').length, 1);
  assert.equal(run('2026-10-12').length, 0);
  assert.equal(run('2026-10-13').length, 4);
});

test('slot order incorporates successful bookings, cancellations, and reschedules', () => {
  const candidates = ['09:00', '11:00', '15:00'].map(start => ({ start: `${day}T${start}:00Z`, end: `${day}T${String(Number(start.slice(0, 2)) + 1).padStart(2, '0')}:00:00Z` }));
  const feedback = [
    { start: candidates[1].start, outcome: 'confirmed' }, { start: candidates[1].start, outcome: 'confirmed' },
    { start: candidates[0].start, outcome: 'cancelled' }, { start: candidates[2].start, outcome: 'rescheduled' }
  ];
  assert.deepEqual(rankCandidateSlots({ candidates, zone, feedback }).map(slot => slot.start.slice(11, 16)), ['11:00', '09:00', '15:00']);
  assert.deepEqual(rankCandidateSlots({ candidates, zone }).map(slot => slot.start.slice(11, 16)), ['09:00', '11:00', '15:00']);
});

test('unusual week alert stays aggregate and proposes a bounded adjustment', () => {
  const days = Array.from({ length: 5 }, (_, offset) => { const date = new Date('2026-10-05T12:00:00Z'); date.setUTCDate(date.getUTCDate() + offset); return date.toISOString().slice(0, 10); });
  const busy = days.slice(0, 3).map(day => ({ start: `${day}T10:00:00Z`, end: `${day}T14:00:00Z` }));
  const signal = weeklyWorkloadAlert({ days, zone, hours, busy, events: [], rules: [], learning: { baselineBusyMinutes: 120 } });
  assert.equal(signal.heavyDays, 3);
  assert.equal(signal.suggestion, 'cluster_meetings');
  assert.equal(JSON.stringify(signal).includes('summary'), false);
  assert.equal(weeklyWorkloadAlert({ days, zone, hours, busy: [], events: [], rules: [], learning: { baselineBusyMinutes: 120 } }), null);
});

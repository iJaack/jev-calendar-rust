import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { BookingService, MemoryStore } from '../lib/booking.js';
import { GoogleCalendarAdapter } from '../lib/calendar.js';
import { SqliteStore } from '../lib/store.js';
const input = { start: '2030-10-05T12:00:00Z', end: '2030-10-05T12:30:00Z', guestName: 'Alex', guestEmail: 'alex@example.com', bufferMinutes: 10, idempotencyKey: 'title-test-key' };

for (const [title, expected] of [['  Product planning — Q4  ', 'Product planning — Q4'], ['   ', 'Meeting with Alex'], [undefined, 'Meeting with Alex']]) {
  test(`booking title is persisted and sent as Google summary: ${JSON.stringify(title)}`, async () => {
    const dir = mkdtempSync(join(tmpdir(), 'jev-title-'));
    const path = join(dir, 'test.sqlite');
    let store, reopened;
    try {
      store = new SqliteStore({ path, encryptionSecret: 'test' });
      let sent;
      const google = new GoogleCalendarAdapter({ tokenProvider: { accessToken: async () => 'test' }, fetchImpl: async (url, init) => {
        assert.match(url, /\/calendars\/primary\/events\?/);
        sent = JSON.parse(init.body);
        return new Response(JSON.stringify({ id: 'event-title' }));
      } });
      const service = new BookingService({ store, calendar: { freeBusy: async () => [], createEvent: x => google.createEvent(x) } });
      const result = await service.book({ ...input, meetingTitle: title });
      assert.equal(sent.summary, expected);
      assert.equal(result.meetingTitle, expected);
      store.db.close(); store = null;
      reopened = new SqliteStore({ path, encryptionSecret: 'test' });
      assert.equal(reopened.get(input.idempotencyKey).meetingTitle, expected);
    } finally { store?.db.close(); reopened?.db.close(); rmSync(dir, { recursive: true, force: true }); }
  });
}

test('invalid titles are rejected before reserving or calling Google', async () => {
  const store = new MemoryStore();
  const service = new BookingService({ store, calendar: { freeBusy: async () => { throw new Error('Unexpected Google request'); } } });
  for (const meetingTitle of ['x'.repeat(201), 'First\nSecond', { title: 'invalid' }, 'control\u0000character']) {
    await assert.rejects(service.book({ ...input, meetingTitle }), /Meeting title/);
  }
  assert.equal(store.records.length, 0);
});

test('title migration preserves existing bookings', () => {
  const dir = mkdtempSync(join(tmpdir(), 'jev-title-migration-'));
  const path = join(dir, 'old.sqlite');
  let store;
  try {
    const old = new DatabaseSync(path);
    old.exec("CREATE TABLE bookings (idempotency_key TEXT PRIMARY KEY, start TEXT NOT NULL, end TEXT NOT NULL, buffer_minutes INTEGER NOT NULL, guest_name TEXT, guest_email TEXT, status TEXT NOT NULL, event_id TEXT, created_at TEXT NOT NULL, meet_link TEXT); INSERT INTO bookings VALUES ('existing-key','2030-01-01','2030-01-02',10,'Guest',NULL,'confirmed','old-event','2026-01-01',NULL)");
    old.close();
    store = new SqliteStore({ path, encryptionSecret: 'test' });
    assert.equal(store.get('existing-key').eventId, 'old-event');
    assert.equal(store.get('existing-key').meetingTitle, null);
  } finally { store?.db.close(); rmSync(dir, { recursive: true, force: true }); }
});

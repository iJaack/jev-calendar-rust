import test from 'node:test';
import assert from 'node:assert/strict';
import { GoogleCalendarAdapter } from '../lib/calendar.js';
import { BookingService, MemoryStore } from '../lib/booking.js';
const range = { start: '2030-10-05T12:00:00Z', end: '2030-10-05T12:30:00Z' };
const json = data => new Response(JSON.stringify(data));
function adapter(handle) {
  return new GoogleCalendarAdapter({ tokenProvider: { accessToken: async () => 'test' }, fetchImpl: async (url, init) => handle(new URL(url), init) });
}

test('discovers hidden and unselected calendars across pages and checks batches of 50', async () => {
  let pages = 0;
  const batches = [];
  const calendars = Array.from({ length: 52 }, (_, i) => ({ id: `calendar-${i}`, accessRole: i === 51 ? 'freeBusyReader' : 'reader', hidden: true, selected: false }));
  const c = adapter((url, init) => {
    if (url.pathname.endsWith('/calendarList')) {
      pages++;
      assert.equal(url.searchParams.get('showHidden'), 'true');
      return json(url.searchParams.has('pageToken') ? { items: calendars.slice(30) } : { items: calendars.slice(0, 30), nextPageToken: 'second' });
    }
    const ids = JSON.parse(init.body).items.map(x => x.id); batches.push(ids);
    return json({ calendars: Object.fromEntries(ids.map(id => [id, { busy: id === 'calendar-51' ? [range] : [] }])) });
  });
  assert.deepEqual(await c.freeBusy(range), [range]);
  assert.equal(pages, 2);
  assert.deepEqual(batches.map(x => x.length), [50, 2]);
  assert.equal(new Set(batches.flat()).size, 52);
});

for (const result of [undefined, { errors: [{ reason: 'notFound' }] }, {}]) {
  test(`missing or failed calendar coverage is never treated as free: ${JSON.stringify(result)}`, async () => {
    const c = adapter(url => url.pathname.endsWith('/calendarList') ? json({ items: [{ id: 'other' }] }) : json({ calendars: { other: result } }));
    await assert.rejects(c.freeBusy(range), /every Google calendar/);
  });
}

test('travel reads all event pages and calendars but skips busy-only metadata', async () => {
  const calls = [];
  const c = adapter(url => {
    calls.push(url);
    if (url.pathname.endsWith('/calendarList')) return json({ items: [{ id: 'primary', accessRole: 'owner' }, { id: 'other@example.com', accessRole: 'reader' }, { id: 'private', accessRole: 'freeBusyReader' }] });
    const event = { start: { dateTime: range.start }, end: { dateTime: range.end }, location: 'Rome', summary: 'Not exposed' };
    if (url.pathname.includes('primary')) return json({ items: [] });
    return json(url.searchParams.has('pageToken') ? { items: [event] } : { items: [], nextPageToken: 'next' });
  });
  assert.deepEqual(await c.events(range), [{ ...range, location: 'Rome', inPerson: true }]);
  assert.equal(calls.length, 4);
  assert.ok(calls.some(url => url.pathname.includes('other%40example.com')));
  assert.ok(!calls.some(url => url.pathname.includes('/private/')));
});

test('workload metadata is available only when explicitly requested from the calendar adapter', async () => {
  const c = adapter(url => url.pathname.endsWith('/calendarList')
    ? json({ items: [{ id: 'work', summary: 'Team1 calendar', accessRole: 'owner' }] })
    : json({ items: [{ start: { dateTime: range.start }, end: { dateTime: range.end }, summary: 'Private Team1 planning' }] }));
  assert.deepEqual(await c.events({ ...range, includeWorkload: true }), [{ ...range, location: '', inPerson: false, summary: 'Private Team1 planning', calendarId: 'work', calendarName: 'Team1 calendar' }]);
  assert.deepEqual(await c.events(range), [{ ...range, location: '', inPerson: false }]);
});

test('a secondary-calendar conflict at final booking check prevents event creation', async () => {
  let created = false;
  const c = adapter((url) => {
    if (url.pathname.endsWith('/calendarList')) return json({ items: [{ id: 'primary' }, { id: 'secondary' }] });
    if (url.pathname.endsWith('/freeBusy')) return json({ calendars: { primary: { busy: [] }, secondary: { busy: [range] } } });
    created = true; return json({ id: 'unexpected' });
  });
  const service = new BookingService({ store: new MemoryStore(), calendar: c });
  await assert.rejects(service.book({ ...range, bufferMinutes: 10, idempotencyKey: 'secondary-conflict' }), /busy/);
  assert.equal(created, false);
});

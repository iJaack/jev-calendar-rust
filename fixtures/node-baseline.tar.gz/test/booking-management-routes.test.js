import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { spawn } from 'node:child_process';
import { createServer } from 'node:net';
import { once } from 'node:events';
import { createHash } from 'node:crypto';

test('guest HTTP lifecycle provides a signed link, moves the original booking and cancels it in demo mode', async t => {
  const dir = mkdtempSync(join(tmpdir(), 'jev-management-'));
  const socket = createServer(); socket.listen(0, '127.0.0.1'); await once(socket, 'listening');
  const port = socket.address().port; await new Promise(resolve => socket.close(resolve));
  const origin = `http://127.0.0.1:${port}`;
  const child = spawn(process.execPath, ['server.js'], { cwd: new URL('..', import.meta.url), env: { PATH: process.env.PATH, PORT: String(port), DATABASE_PATH: join(dir, 'test.sqlite'), APP_ENCRYPTION_KEY: 'test-only', DEMO_MODE: 'true', APP_BASE_URL: origin }, stdio: ['ignore', 'pipe', 'pipe'] });
  t.after(async () => { if (child.exitCode === null) { child.kill(); await once(child, 'exit'); } rmSync(dir, { recursive: true, force: true }); });
  await Promise.race([once(child.stdout, 'data'), once(child, 'exit').then(() => { throw new Error('Test server did not start'); })]);
  const post = (route, body) => fetch(origin + route, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
  const first = { date: '2030-10-07', viewerTimeZone: 'Europe/Rome', durationMinutes: 30 };
  const slots = await (await post('/api/availability', first)).json();
  const request = { ...first, ...slots.candidates[0], idempotencyKey: 'demo-management-routes', guestName: 'Demo Guest', guestEmail: 'demo@example.test', meetingTitle: 'Review plans' };
  const created = await post('/api/book', request);
  assert.equal(created.status, 201);
  const { booking } = await created.json();
  const replay = await post('/api/book', request);
  assert.equal(replay.status, 200);
  assert.equal((await replay.json()).booking.eventId, booking.eventId);
  assert.equal((await post('/api/book', { ...request, guestEmail: 'other@example.test' })).status, 400);
  assert.equal(booking.googleAccountId, undefined);
  const url = new URL(booking.managementUrl);
  assert.equal(url.origin, origin); assert.equal(url.pathname, '/manage'); assert.equal(url.search, '');
  const token = new URLSearchParams(url.hash.slice(1)).get('token');
  assert.equal((await fetch(origin + '/manage')).status, 200);
  assert.equal((await post('/api/booking/view', { token: 'tampered' })).status, 400);
  assert.equal((await fetch(origin + '/api/booking/change')).status, 404);
  const view = await (await post('/api/booking/view', { token })).json();
  assert.equal(view.status, 'confirmed'); assert.equal(view.meetingTitle, 'Review plans'); assert.equal(view.guestEmail, undefined);
  const nextDay = { date: '2030-10-08', viewerTimeZone: first.viewerTimeZone };
  const nextSlots = await (await post('/api/booking/slots', { token, ...nextDay })).json();
  const movedResponse = await post('/api/booking/change', { token, action: 'reschedule', revision: view.revision, ...nextDay, ...nextSlots.candidates[0] });
  assert.equal(movedResponse.status, 200);
  const moved = await movedResponse.json(); assert.equal(moved.start, nextSlots.candidates[0].start);
  const cancelResponse = await post('/api/booking/change', { token, action: 'cancel', revision: moved.revision });
  assert.equal(cancelResponse.status, 200); assert.equal((await cancelResponse.json()).status, 'cancelled');
  assert.equal((await (await post('/api/booking/view', { token })).json()).status, 'cancelled');
});

test('JAACK OS owner write is separately authenticated, revision checked, idempotent and reconciles an ambiguous provider response', async t => {
  const dir = mkdtempSync(join(tmpdir(), 'jev-owner-write-'));
  const socket = createServer(); socket.listen(0, '127.0.0.1'); await once(socket, 'listening');
  const port = socket.address().port; await new Promise(resolve => socket.close(resolve));
  const origin = `http://127.0.0.1:${port}`;
  const readToken = 'read-token-for-disposable-jaack-os-test-0001';
  const writeToken = 'write-token-for-disposable-jaack-os-test-0001';
  const child = spawn(process.execPath, ['server.js'], { cwd: new URL('..', import.meta.url), env: {
    PATH: process.env.PATH, PORT: String(port), DATABASE_PATH: join(dir, 'test.sqlite'), APP_ENCRYPTION_KEY: 'test-only',
    DEMO_MODE: 'true', APP_BASE_URL: origin, JEV_JAACK_OS_READ_TOKEN: readToken,
    JEV_JAACK_OS_WRITE_TOKEN: writeToken, JEV_TEST_MODE: 'true', JEV_TEST_AMBIGUOUS_CANCEL: 'true',
  }, stdio: ['ignore', 'pipe', 'pipe'] });
  t.after(async () => { if (child.exitCode === null) { child.kill(); await once(child, 'exit'); } rmSync(dir, { recursive: true, force: true }); });
  await Promise.race([once(child.stdout, 'data'), once(child, 'exit').then(() => { throw new Error('Test server did not start'); })]);
  const post = (route, body, token, requestId) => fetch(origin + route, { method: 'POST', headers: {
    'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}),
    ...(requestId ? { 'Idempotency-Key': requestId } : {}),
  }, body: JSON.stringify(body) });
  const first = { date: '2030-10-07', viewerTimeZone: 'Europe/Rome', durationMinutes: 30 };
  const slots = await (await post('/api/availability', first)).json();
  const created = await post('/api/book', { ...first, ...slots.candidates[0], idempotencyKey: 'owner-write-disposable-booking', guestName: 'Demo Guest' });
  assert.equal(created.status, 201);
  const ownerList = await fetch(origin + '/api/integrations/jaack-os/bookings?limit=10&offset=0', { headers: { Authorization: `Bearer ${readToken}` } });
  const sourceId = (await ownerList.json()).bookings[0].id;
  const route = `/api/integrations/jaack-os/bookings/${sourceId}/change`;
  const staleId = 'd58a80ef-13c7-47a1-88f2-8fe8b053a0da';
  assert.equal((await post(route, { action: 'cancel', revision: 12 }, readToken, staleId)).status, 401,
    'read token must not authorize a write');
  assert.equal((await post(route, { action: 'cancel', revision: 12 }, 'wrong-write-token-for-disposable-test-0001', staleId)).status, 401);
  assert.equal((await post(route, { action: 'cancel', revision: 12 }, writeToken, staleId)).status, 409,
    'stale expected revision must be rejected');
  assert.equal((await post(route, { action: 'cancel', revision: 0, start: 'unexpected' }, writeToken,
    'fb254836-e5a6-4e0e-8c22-f8919675f421')).status, 400, 'unknown body fields must be rejected');
  const nextDay = { date: '2030-10-08', viewerTimeZone: 'Europe/Rome', durationMinutes: 30 };
  const nextSlots = await (await post('/api/availability', nextDay)).json();
  const moveId = 'd3c6c7a1-8d70-4768-a132-d51ee27c8eab';
  const movePayload = { action: 'reschedule', revision: 0, date: nextDay.date, viewerTimeZone: nextDay.viewerTimeZone, ...nextSlots.candidates[0] };
  const moveHash = createHash('sha256').update(JSON.stringify({ sourceId, action: 'reschedule', revision: movePayload.revision,
    start: movePayload.start, end: movePayload.end, date: movePayload.date, viewerTimeZone: movePayload.viewerTimeZone })).digest('hex');
  const moved = await post(route, movePayload, writeToken, moveId);
  assert.equal(moved.status, 200);
  const movedBody = await moved.json();
  assert.deepEqual(Object.keys(movedBody), ['booking', 'replayed']);
  assert.deepEqual(Object.keys(movedBody.booking).sort(), ['id', 'source', 'start', 'end', 'status', 'revision', 'pendingAction', 'createdAt'].sort());
  assert.equal('meetLink' in movedBody.booking, false);
  assert.equal('meetingTitle' in movedBody.booking, false);
  assert.equal(movedBody.booking.start, nextSlots.candidates[0].start);
  assert.equal(movedBody.booking.revision, 1);
  const journalUrl = `/api/integrations/jaack-os/booking-changes/${moveId}?sourceId=${sourceId}&requestHash=${moveHash}`;
  const journalResponse = await fetch(origin + journalUrl, { headers: { Authorization: `Bearer ${readToken}` } });
  assert.equal(journalResponse.status, 200);
  const journalBody = await journalResponse.json();
  assert.deepEqual(Object.keys(journalBody).sort(), ['requestId', 'sourceId', 'requestHash', 'state'].sort());
  assert.deepEqual(journalBody, { requestId: moveId, sourceId, requestHash: moveHash, state: 'succeeded' });
  assert.equal(JSON.stringify(journalBody).includes('guest'), false, 'change journal contains no guest fields or response payload');
  assert.equal((await fetch(origin + journalUrl, { headers: { Authorization: `Bearer ${writeToken}` } })).status, 401,
    'write token does not grant journal read access');
  assert.equal((await fetch(origin + `/api/integrations/jaack-os/booking-changes/${moveId}?sourceId=${sourceId}&requestHash=${'0'.repeat(64)}`,
    { headers: { Authorization: `Bearer ${readToken}` } })).status, 404, 'journal lookup requires the exact request hash');
  assert.equal((await fetch(origin + `/api/integrations/jaack-os/booking-changes/${moveId}?sourceId=${'0'.repeat(64)}&requestHash=${moveHash}`,
    { headers: { Authorization: `Bearer ${readToken}` } })).status, 404, 'journal lookup requires the exact source ID');
  assert.equal((await (await fetch(origin + '/__test/provider-state')).json()).mutationCount, 1);
  const moveReplay = await post(route, movePayload, writeToken, moveId);
  assert.equal(moveReplay.status, 200);
  assert.equal((await moveReplay.json()).replayed, true);
  assert.equal((await post(route, { ...movePayload, revision: 1 }, writeToken, moveId)).status, 409,
    'an idempotency key cannot be reused with a different body');
  const newMoveId = '4af11f0b-b770-4b24-b786-fd4c555ca99d';
  assert.equal((await post(route, { ...movePayload, revision: 1 }, writeToken, newMoveId)).status, 409,
    'a new request must not claim a reschedule that already happened');
  assert.equal((await (await fetch(origin + '/__test/provider-state')).json()).mutationCount, 1,
    'replaying a completed reschedule must not dispatch a second provider mutation');
  assert.equal((await post('/__test/owner-change-pending', { requestId: moveId })).status, 200);
  const crashReplay = await post(route, movePayload, writeToken, moveId);
  assert.equal(crashReplay.status, 200);
  assert.equal((await crashReplay.json()).booking.revision, 1,
    'a pending journal whose provider change already applied must reconcile as success');
  assert.equal((await (await fetch(origin + '/__test/provider-state')).json()).mutationCount, 1,
    'pending journal recovery must not dispatch a duplicate mutation');
  const requestId = '3d741dd9-835b-4c73-bce1-88f0b5be4c94';
  const payload = { action: 'cancel', revision: 1 };
  const ambiguous = await post(route, payload, writeToken, requestId);
  assert.equal(ambiguous.status, 503, await ambiguous.clone().text());
  assert.deepEqual(await ambiguous.json(), {
    error: 'The change could not be confirmed. Reload this page and use Retry; your request has been saved.',
    state: 'uncertain', pendingAction: 'cancel',
  });
  const replay = await post(route, payload, writeToken, requestId);
  assert.equal(replay.status, 200);
  const result = await replay.json();
  assert.equal(result.replayed, true);
  assert.equal(result.booking.status, 'cancelled');
  assert.equal(result.booking.revision, 2);
  assert.equal((await (await fetch(origin + '/__test/provider-state')).json()).mutationCount, 2,
    'retry after uncertain provider response must reconcile without dispatching another mutation');
  const newCancelId = 'b1a03636-e954-4c9f-afdc-84c33bac8c66';
  assert.equal((await post(route, { action: 'cancel', revision: 2 }, writeToken, newCancelId)).status, 409,
    'a new request must not claim a cancellation that already happened');
  assert.equal((await (await fetch(origin + '/__test/provider-state')).json()).mutationCount, 2,
    'a new UUID after cancellation must not dispatch another provider mutation');
  const readback = await fetch(origin + `/api/integrations/jaack-os/bookings/${sourceId}`, { headers: { Authorization: `Bearer ${readToken}` } });
  assert.equal((await readback.json()).booking.status, 'cancelled');
});

test('owner retry does not report success when provider state changes between reconciliation and dispatch', async t => {
  const dir = mkdtempSync(join(tmpdir(), 'jev-owner-race-'));
  const socket = createServer(); socket.listen(0, '127.0.0.1'); await once(socket, 'listening');
  const port = socket.address().port; await new Promise(resolve => socket.close(resolve));
  const origin = `http://127.0.0.1:${port}`;
  const readToken = 'read-token-for-disposable-race-test-0001';
  const writeToken = 'write-token-for-disposable-race-test-0001';
  const child = spawn(process.execPath, ['server.js'], { cwd: new URL('..', import.meta.url), env: {
    PATH: process.env.PATH, PORT: String(port), DATABASE_PATH: join(dir, 'test.sqlite'), APP_ENCRYPTION_KEY: 'test-only',
    DEMO_MODE: 'true', APP_BASE_URL: origin, JEV_JAACK_OS_READ_TOKEN: readToken,
    JEV_JAACK_OS_WRITE_TOKEN: writeToken, JEV_TEST_MODE: 'true', JEV_TEST_FAIL_BEFORE_RESCHEDULE: 'true',
  }, stdio: ['ignore', 'pipe', 'pipe'] });
  t.after(async () => { if (child.exitCode === null) { child.kill(); await once(child, 'exit'); } rmSync(dir, { recursive: true, force: true }); });
  await Promise.race([once(child.stdout, 'data'), once(child, 'exit').then(() => { throw new Error('Test server did not start'); })]);
  const post = (route, body, token, requestId) => fetch(origin + route, { method: 'POST', headers: {
    'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}),
    ...(requestId ? { 'Idempotency-Key': requestId } : {}),
  }, body: JSON.stringify(body) });
  const day = { date: '2030-10-07', viewerTimeZone: 'Europe/Rome', durationMinutes: 30 };
  const slots = await (await post('/api/availability', day)).json();
  assert.equal((await post('/api/book', { ...day, ...slots.candidates[0], idempotencyKey: 'owner-write-race-booking' })).status, 201);
  const list = await fetch(origin + '/api/integrations/jaack-os/bookings?limit=10&offset=0', { headers: { Authorization: `Bearer ${readToken}` } });
  const sourceId = (await list.json()).bookings[0].id;
  const route = `/api/integrations/jaack-os/bookings/${sourceId}/change`;
  const targetDay = { date: '2030-10-08', viewerTimeZone: 'Europe/Rome', durationMinutes: 30 };
  const targetSlots = await (await post('/api/availability', targetDay)).json();
  const requestId = '48d040bd-b897-4f0b-83e0-7af8406d869a';
  const payload = { action: 'reschedule', revision: 0, date: targetDay.date,
    viewerTimeZone: targetDay.viewerTimeZone, ...targetSlots.candidates[0] };
  assert.equal((await post(route, payload, writeToken, requestId)).status, 503,
    'injected initial provider failure leaves the exact intent pending');
  assert.equal((await post('/__test/external-change-after-read', {
    sourceId, start: '2030-10-09T09:00:00+02:00', end: '2030-10-09T09:30:00+02:00',
  })).status, 200);
  const retry = await post(route, payload, writeToken, requestId);
  assert.equal(retry.status, 409, await retry.clone().text());
  assert.equal((await retry.json()).booking, undefined, 'external provider drift must not be returned as success');
  assert.equal((await (await fetch(origin + '/__test/provider-state')).json()).mutationCount, 2,
    'retry reaches the provider precondition once and does not issue another write after readback changes');
  assert.equal((await post(route, payload, writeToken, requestId)).status, 409,
    'rejected replay remains rejected for the same request UUID');
});

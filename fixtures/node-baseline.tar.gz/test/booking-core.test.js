import test from 'node:test';
import assert from 'node:assert/strict';
import { dateKeyInZone, generateCandidates, overlaps, hardConstraint, isValidTimeZone, zonedEpoch } from '../lib/scheduling.js';
import { GoogleRoutesAdapter, travelBuffer } from '../lib/travel.js';
import { applyJevAdvisory, buildJevPayload, boundedJevAdvice, boundedJevNotice, boundedJevWeek, ENDPOINT, JevSystemOneClient, MODEL } from '../lib/jev.js';
import { BookingService, MemoryStore } from '../lib/booking.js';
import { GoogleCalendarAdapter } from '../lib/calendar.js';
import { hostTravelConstraints } from '../lib/host-travel.js';
import { AddressSelectionCodec, PhotonAddressAdapter } from '../lib/address-search.js';

test('generates candidates around busy events while preserving required travel buffers', () => {
  const day = '2026-10-05';
  const candidates = generateCandidates({ day, busy: [{ start: `${day}T10:00:00.000Z`, end: `${day}T11:00:00.000Z` }], durationMinutes: 30, bufferMinutes: 20, hours: { start: 9, end: 13 }, zone: 'UTC' });
  assert.deepEqual(candidates.map((x) => x.start), [`${day}T09:00:00.000Z`, `${day}T11:20:00.000Z`, `${day}T11:50:00.000Z`, `${day}T12:20:00.000Z`]);
});

test('future busy events cannot extend candidates beyond host working hours', () => {
  const candidates = generateCandidates({
    day: '2026-09-29',
    busy: [{ start: '2026-09-29T22:00:00.000Z', end: '2026-09-29T23:00:00.000Z' }],
    durationMinutes: 30, bufferMinutes: 20, hours: { start: 9, end: 18 }, zone: 'Europe/Rome', limit: 96
  });
  assert.equal(candidates[0].start, '2026-09-29T07:00:00.000Z');
  assert.equal(candidates.at(-1).end, '2026-09-29T16:00:00.000Z');
  assert.equal(candidates.length, 18);
});

test('today excludes elapsed slots before applying the result limit', () => {
  const input = { day: '2026-09-21', durationMinutes: 30, bufferMinutes: 10, hours: { start: 9, end: 18 }, zone: 'Europe/Rome', limit: 2 };
  const candidates = generateCandidates({ ...input, notBefore: Date.parse('2026-09-21T14:00:00Z') });
  assert.deepEqual(candidates.map(x => x.start), ['2026-09-21T14:00:00.000Z', '2026-09-21T14:30:00.000Z']);
  assert.deepEqual(generateCandidates({ ...input, notBefore: Date.parse('2026-09-21T16:00:00Z') }), []);
});

test('a meeting exactly at the advance-notice cutoff is allowed', () => {
  const cutoff = Date.parse('2026-09-21T14:00:00Z');
  const candidates = generateCandidates({ day: '2026-09-21', durationMinutes: 30, bufferMinutes: 0, hours: { start: 15, end: 17 }, zone: 'Europe/Rome', notBefore: cutoff });
  assert.equal(candidates[0].start, new Date(cutoff).toISOString());
});

test('working hours are converted from Europe/Rome with DST awareness', () => {
  const summer = generateCandidates({ day: '2026-10-05', busy: [], durationMinutes: 30, bufferMinutes: 0, hours: { start: 9, end: 10 }, zone: 'Europe/Rome' });
  const winter = generateCandidates({ day: '2026-12-05', busy: [], durationMinutes: 30, bufferMinutes: 0, hours: { start: 9, end: 10 }, zone: 'Europe/Rome' });
  assert.equal(summer[0].start, '2026-10-05T07:00:00.000Z');
  assert.equal(winter[0].start, '2026-12-05T08:00:00.000Z');
});

test('viewer dates and day boundaries are converted across IANA time zones', () => {
  assert.equal(isValidTimeZone('America/New_York'), true);
  assert.equal(isValidTimeZone('Not/A_Timezone'), false);
  assert.equal(dateKeyInZone('2026-09-21T01:00:00.000Z', 'America/New_York'), '2026-09-20');
  assert.equal(new Date(zonedEpoch('2026-09-21', 0, 'Asia/Tokyo')).toISOString(), '2026-09-20T15:00:00.000Z');
});

test('hard constraints reject busy overlap, insufficient buffer, and invalid duration', () => {
  const busy = [{ start: '2026-10-05T10:00:00.000Z', end: '2026-10-05T11:00:00.000Z' }];
  assert.equal(overlaps('2026-10-05T10:30:00.000Z', '2026-10-05T11:30:00.000Z', busy[0]), true);
  assert.equal(hardConstraint({ start: '2026-10-05T11:10:00.000Z', end: '2026-10-05T11:40:00.000Z', busy, bufferMinutes: 20 }), 'required_buffer');
  assert.equal(hardConstraint({ start: '2026-10-05T11:20:00.000Z', end: '2026-10-05T11:50:00.000Z', busy, bufferMinutes: 20 }), null);
  assert.equal(hardConstraint({ start: 'bad', end: '2026-10-05T11:50:00.000Z', busy, bufferMinutes: 20 }), 'invalid_interval');
});

test('event-specific buffers reserve travel only around in-person events', () => {
  const physical = [{ start: '2026-10-05T10:00:00.000Z', end: '2026-10-05T11:00:00.000Z', beforeBufferMinutes: 35, afterBufferMinutes: 25 }];
  assert.equal(hardConstraint({ start: '2026-10-05T09:00:00.000Z', end: '2026-10-05T09:30:00.000Z', busy: physical, bufferMinutes: 10 }), 'required_buffer');
  assert.equal(hardConstraint({ start: '2026-10-05T08:55:00.000Z', end: '2026-10-05T09:25:00.000Z', busy: physical, bufferMinutes: 10 }), null);
  assert.equal(hardConstraint({ start: '2026-10-05T11:20:00.000Z', end: '2026-10-05T11:50:00.000Z', busy: physical, bufferMinutes: 10 }), 'required_buffer');
  assert.equal(hardConstraint({ start: '2026-10-05T11:25:00.000Z', end: '2026-10-05T11:55:00.000Z', busy: physical, bufferMinutes: 10 }), null);
});

test('travel buffer is derived from an authoritative route duration, then bounded policy', () => {
  assert.equal(travelBuffer({ routeDurationSeconds: 901, mode: 'DRIVE', extraMinutes: 4, minimumMinutes: 10 }), 30);
  assert.throws(() => travelBuffer({ mode: 'DRIVE' }), /route duration/i);
  assert.throws(() => travelBuffer({ routeDurationSeconds: 10, extraMinutes: 31 }), /bounded/i);
});

test('Google Routes requests distance with duration for rounded Jev context', async () => {
  let fieldMask;
  const routes = new GoogleRoutesAdapter({ apiKey: 'fixture', fetchImpl: async (_url, init) => {
    fieldMask = init.headers['X-Goog-FieldMask'];
    return new Response(JSON.stringify({ routes: [{ duration: '901s', distanceMeters: 3421 }] }));
  } });
  const route = await routes.duration({ origin: 'A', destination: 'B', mode: 'DRIVE' });
  assert.equal(fieldMask, 'routes.duration,routes.distanceMeters');
  assert.equal(route.seconds, 901);
  assert.equal(route.distanceMeters, 3421);
});

test('Jev advice is advisory and cannot remove deterministic travel buffer', async () => {
  const fallback = await boundedJevAdvice({ client: { advise: async () => ({ mode: 'TRANSIT', extraBufferMinutes: 99 }) }, payload: { candidateCount: 3 } });
  assert.equal(fallback.source, 'fallback');
  const applied = applyJevAdvisory({ baseBufferMinutes: 22, advice: { source: 'jev', mode: 'WALK', extraBufferMinutes: 5 } });
  assert.deepEqual(applied, { mode: 'WALK', bufferMinutes: 27, source: 'jev' });
  assert.equal(applyJevAdvisory({ baseBufferMinutes: 22, advice: { source: 'jev', extraBufferMinutes: -10 } }).bufferMinutes, 22);
});

test('daily Jev notice only extends the owner minimum and falls back safely', async () => {
  const upcomingDays = [{ busyMinutes: 240, typeMinutes: { meetings: 0, focus: 180, deadline: 0 } }];
  let sent;
  const client = new JevSystemOneClient({ token: 'fixture', fetchImpl: async (_url, init) => {
    sent = JSON.parse(init.body);
    return new Response(JSON.stringify({ model: MODEL, answers: { booking_notice: { type: 'choice', choice: 'EXTEND_50', probabilities: { BASE: 0.1, EXTEND_50: 0.8, DOUBLE: 0.1 }, confidence: 0.8 } } }));
  } });
  assert.deepEqual(await boundedJevNotice({ client, baseMinutes: 480, baselineBusyMinutes: 120, upcomingDays }), { source: 'jev', minutes: 720 });
  assert.equal(JSON.stringify(sent).includes('focus'), true);
  assert.deepEqual(await boundedJevNotice({ client: { adviseNotice: async () => 'INVALID' }, baseMinutes: 480, baselineBusyMinutes: 120, upcomingDays }), { source: 'fallback', minutes: 480 });
  assert.deepEqual(await boundedJevNotice({ client: { adviseNotice: async () => { throw new Error('offline'); } }, baseMinutes: 480, baselineBusyMinutes: 120, upcomingDays }), { source: 'fallback', minutes: 480 });
});

test('weekly Jev suggestion uses aggregate context and cannot change the calendar', async () => {
  const alert = { heavyDays: 3, busyMinutes: 900, typicalBusyMinutes: 600, typeMinutes: { meetings: 600, focus: 200, deadline: 0 }, suggestion: 'cluster_meetings' };
  let sent;
  const client = new JevSystemOneClient({ token: 'fixture', fetchImpl: async (_url, init) => {
    sent = JSON.parse(init.body);
    return new Response(JSON.stringify({ model: MODEL, answers: { weekly_adjustment: { type: 'choice', choice: 'protect_focus', probabilities: { cluster_meetings: 0.1, protect_focus: 0.8, protect_deadline: 0.1 }, confidence: 0.8 } } }));
  } });
  assert.deepEqual(await boundedJevWeek({ client, alert }), { source: 'jev', suggestion: 'protect_focus' });
  assert.deepEqual(Object.keys(sent.state).sort(), ['busyMinutes', 'heavyDays', 'purpose', 'schemaVersion', 'typeMinutes', 'typicalBusyMinutes']);
  assert.deepEqual(await boundedJevWeek({ client: { adviseWeek: async () => 'bad' }, alert }), { source: 'fallback', suggestion: 'cluster_meetings' });
});

test('Jev privacy payload contains sanitized scheduling features, never raw PII', () => {
  const payload = buildJevPayload({ title: 'Board meeting: acquisition', attendees: ['ceo@example.com'], origin: 'Via Roma 10, Milan', destination: 'Private house, Rome', candidates: [{ start: '2026-10-05T10:00:00.000Z', end: '2026-10-05T10:30:00.000Z' }], routeDurationSeconds: 1234, routeDistanceMeters: 3421, direction: 'TO_EVENT', minimumMinutes: 10 });
  const json = JSON.stringify(payload);
  assert.match(json, /jev-1\.13\.0/);
  for (const forbidden of ['Board meeting', 'ceo@example.com', 'Via Roma', 'Private house']) assert.doesNotMatch(json, new RegExp(forbidden));
  assert.deepEqual(Object.keys(payload).sort(), ['candidateWindows', 'model', 'ownerMinimumBufferMinutes', 'routeDistanceBucketKm', 'routeDurationBucketMinutes', 'schemaVersion', 'tripDirection']);
  assert.equal(payload.routeDistanceBucketKm, 3);
  assert.equal(payload.tripDirection, 'TO_EVENT');
  assert.equal(payload.ownerMinimumBufferMinutes, 10);
});

test('Jev client uses the pinned System One state/questions protocol and validates typed advice', async () => {
  let sent;
  const client = new JevSystemOneClient({ token: 'fixture', fetchImpl: async (url, init) => {
    assert.equal(url, ENDPOINT); assert.equal(init.redirect, 'error'); sent = JSON.parse(init.body);
    return new Response(JSON.stringify({ model: MODEL, answers: {
      travel_mode: { type: 'choice', choice: 'TRANSIT', probabilities: { DRIVE: 0.1, WALK: 0.1, BICYCLE: 0.1, TRANSIT: 0.7 }, confidence: 0.7 },
      extra_buffer: { type: 'choice', choice: 'MIN_10', probabilities: { MIN_0: 0.05, MIN_5: 0.15, MIN_10: 0.7, MIN_15: 0.1 }, confidence: 0.7 }
    } }));
  } });
  assert.deepEqual(await client.advise(buildJevPayload({ routeDurationSeconds: 901 })), { mode: 'TRANSIT', extraBufferMinutes: 10 });
  assert.equal(sent.model, 'jev-1.13.0'); assert.ok(sent.state); assert.deepEqual(Object.keys(sent.questions), ['travel_mode', 'extra_buffer']); assert.equal(sent.input, undefined);
});

test('Jev accepts each confident decision independently and falls back for uncertain ones', async () => {
  const client = new JevSystemOneClient({ token: 'fixture', fetchImpl: async () => new Response(JSON.stringify({ model: MODEL, answers: {
    travel_mode: { type: 'choice', choice: 'WALK', probabilities: { DRIVE: 0.03, WALK: 0.87, BICYCLE: 0.05, TRANSIT: 0.05 }, confidence: 0.87 },
    extra_buffer: { type: 'choice', choice: 'MIN_5', probabilities: { MIN_0: 0.24, MIN_5: 0.26, MIN_10: 0.25, MIN_15: 0.25 }, confidence: 0.24 }
  } })) });
  assert.deepEqual(await client.advise(buildJevPayload({ routeDurationSeconds: 901 })), { mode: 'WALK', extraBufferMinutes: 0 });
});

test('Photon searches complete addresses and signed selections reject tampering', async () => {
  let requestedUrl;
  const addresses = new PhotonAddressAdapter({ fetchImpl: async (url) => {
    requestedUrl = url;
    return new Response(JSON.stringify({ features: [{ properties: { osm_type: 'N', osm_id: 42, name: 'Studio', street: 'Via Torino', housenumber: '1', postcode: '20123', city: 'Milan', state: 'Lombardy', country: 'Italy' }, geometry: { coordinates: [9.1868, 45.4631] } }] }));
  } });
  const [selection] = await addresses.autocomplete({ input: 'Via Torino 1 Milano', languageCode: 'it' });
  assert.deepEqual(selection, { providerId: 'N:42', text: 'Studio, Via Torino 1, 20123 Milan, Lombardy, Italy', mainText: 'Studio', secondaryText: 'Via Torino 1, 20123 Milan, Lombardy, Italy', latitude: 45.4631, longitude: 9.1868 });
  assert.match(requestedUrl, /q=Via\+Torino\+1\+Milano&limit=6&lang=default$/);
  const codec = new AddressSelectionCodec('test-secret');
  const token = codec.encode(selection);
  assert.deepEqual(codec.decode(token), { provider: 'photon', providerId: 'N:42', formattedAddress: selection.text, location: { latitude: 45.4631, longitude: 9.1868 } });
  assert.throws(() => codec.decode(`${token}x`), /choose an address/i);
});

test('Google Calendar event creation requests and returns a unique Meet conference', async () => {
  let request;
  const calendar = new GoogleCalendarAdapter({ tokenProvider: { accessToken: async () => 'token' }, fetchImpl: async (url, init) => {
    request = { url, init, body: JSON.parse(init.body) };
    return new Response(JSON.stringify({ id: 'google-event', hangoutLink: 'https://meet.google.com/abc-defg-hij' }));
  } });
  const event = await calendar.createEvent({ start: '2026-10-05T12:00:00.000Z', end: '2026-10-05T12:30:00.000Z', guestName: 'Guest', guestEmail: 'guest@example.com' });
  assert.deepEqual(event, { id: 'google-event', meetLink: 'https://meet.google.com/abc-defg-hij' });
  assert.match(request.url, /events\?sendUpdates=all&conferenceDataVersion=1$/);
  assert.equal(request.body.conferenceData.createRequest.conferenceSolutionKey.type, 'hangoutsMeet');
  assert.ok(request.body.conferenceData.createRequest.requestId);
  assert.deepEqual(request.body.attendees, [{ email: 'guest@example.com', displayName: 'Guest' }]);
});

test('Google Calendar primary calendar supplies the live host time zone', async () => {
  const calendar = new GoogleCalendarAdapter({ tokenProvider: { accessToken: async () => 'token' }, fetchImpl: async (url) => {
    assert.match(url, /\/users\/me\/settings\/timezone$/);
    return new Response(JSON.stringify({ value: 'America/New_York' }));
  } });
  assert.equal(await calendar.timeZone(), 'America/New_York');
});

test('Google Calendar exposes only timed event metadata needed for host travel', async () => {
  const calendar = new GoogleCalendarAdapter({ tokenProvider: { accessToken: async () => 'token' }, fetchImpl: async (url) => {
    if (url.includes('/calendarList?')) return new Response(JSON.stringify({ items: [{ id: 'primary', accessRole: 'owner' }] }));
    assert.match(url, /\/calendars\/primary\/events\?/);
    return new Response(JSON.stringify({ items: [
      { status: 'confirmed', start: { dateTime: '2026-10-05T10:00:00Z' }, end: { dateTime: '2026-10-05T11:00:00Z' }, location: 'Piazza Duomo, Milano', summary: 'Private title' },
      { status: 'confirmed', start: { dateTime: '2026-10-05T12:00:00Z' }, end: { dateTime: '2026-10-05T12:30:00Z' }, location: 'https://meet.google.com/abc-defg-hij' },
      { status: 'confirmed', start: { date: '2026-10-05' }, end: { date: '2026-10-06' }, location: 'Milan' },
      { status: 'cancelled', start: { dateTime: '2026-10-05T13:00:00Z' }, end: { dateTime: '2026-10-05T14:00:00Z' }, location: 'Rome' }
    ] }));
  } });
  assert.deepEqual(await calendar.events({ start: '2026-10-05T00:00:00Z', end: '2026-10-06T00:00:00Z' }), [
    { start: '2026-10-05T10:00:00Z', end: '2026-10-05T11:00:00Z', location: 'Piazza Duomo, Milano', inPerson: true },
    { start: '2026-10-05T12:00:00Z', end: '2026-10-05T12:30:00Z', location: 'https://meet.google.com/abc-defg-hij', inPerson: false }
  ]);
});

test('host travel routes from the base only around adjacent in-person events', async () => {
  const calls = [];
  const routes = { duration: async (input) => { calls.push(input); return { seconds: 900, provider: 'google-routes', mode: input.mode }; } };
  const result = await hostTravelConstraints({
    events: [{ start: '2026-10-05T10:00:00.000Z', end: '2026-10-05T11:00:00.000Z', location: 'Piazza Duomo, Milano', inPerson: true }],
    baseLocation: 'Milano Centrale',
    routes,
    jevClient: { advise: async () => { throw new Error('offline'); } },
    candidates: [{ start: '2026-10-05T09:00:00.000Z', end: '2026-10-05T09:30:00.000Z' }, { start: '2026-10-05T11:30:00.000Z', end: '2026-10-05T12:00:00.000Z' }],
    minimumMinutes: 10,
    now: Date.parse('2026-10-01T00:00:00Z')
  });
  assert.deepEqual(result.constraints, [{ start: '2026-10-05T10:00:00.000Z', end: '2026-10-05T11:00:00.000Z', beforeBufferMinutes: 25, afterBufferMinutes: 25 }]);
  assert.equal(result.maximumBufferMinutes, 25);
  assert.equal(result.routeProvider, 'google-routes');
  assert.equal(result.adviceSource, 'fallback');
  assert.deepEqual(calls.map(({ origin, destination }) => [origin, destination]), [['Milano Centrale', 'Piazza Duomo, Milano'], ['Piazza Duomo, Milano', 'Milano Centrale']]);
});

test('host travel reports fallback when only one direction accepts Jev advice', async () => {
  let calls = 0;
  const result = await hostTravelConstraints({
    events: [{ start: '2026-10-05T10:00:00.000Z', end: '2026-10-05T11:00:00.000Z', location: 'Piazza Duomo, Milano', inPerson: true }],
    baseLocation: 'Milano Centrale',
    routes: { duration: async ({ mode }) => ({ seconds: 900, provider: 'google-routes', mode }) },
    jevClient: { advise: async () => ++calls === 1 ? { mode: 'DRIVE', extraBufferMinutes: 5 } : Promise.reject(new Error('offline')) },
    candidates: [{ start: '2026-10-05T09:00:00.000Z', end: '2026-10-05T09:30:00.000Z' }, { start: '2026-10-05T11:30:00.000Z', end: '2026-10-05T12:00:00.000Z' }],
    minimumMinutes: 10,
    now: Date.parse('2026-10-01T00:00:00Z')
  });
  assert.equal(calls, 2);
  assert.equal(result.adviceSource, 'fallback');
  assert.deepEqual(result.constraints[0], { start: '2026-10-05T10:00:00.000Z', end: '2026-10-05T11:00:00.000Z', beforeBufferMinutes: 30, afterBufferMinutes: 25 });
});

test('host travel falls back to driving when the advised mode has no route', async () => {
  const payloads = [];
  const result = await hostTravelConstraints({
    events: [{ start: '2026-10-05T10:00:00.000Z', end: '2026-10-05T11:00:00.000Z', location: 'Event address', inPerson: true }],
    baseLocation: 'Base address',
    routes: { duration: async ({ mode }) => {
      if (mode === 'WALK') throw new Error('No walking route');
      return { seconds: 900, distanceMeters: 2600, provider: 'google-routes', mode };
    } },
    jevClient: { advise: async (payload) => { payloads.push(payload); return { mode: 'WALK', extraBufferMinutes: 5 }; } },
    candidates: [{ start: '2026-10-05T09:00:00.000Z', end: '2026-10-05T09:30:00.000Z' }, { start: '2026-10-05T11:30:00.000Z', end: '2026-10-05T12:00:00.000Z' }],
    minimumMinutes: 10,
    now: Date.parse('2026-10-01T00:00:00Z')
  });
  assert.deepEqual(payloads.map(({ tripDirection, routeDistanceBucketKm }) => [tripDirection, routeDistanceBucketKm]), [['TO_EVENT', 3], ['FROM_EVENT', 3]]);
  assert.equal(result.adviceSource, 'fallback');
  assert.equal(result.maximumBufferMinutes, 25);
});

test('booking is idempotent and concurrent conflicting requests cannot create two events', async () => {
  const store = new MemoryStore();
  let creates = 0;
  const calendar = { freeBusy: async () => [], createEvent: async () => ({ id: `event-${++creates}`, meetLink: 'https://meet.google.com/abc-defg-hij' }) };
  const service = new BookingService({ store, calendar, clock: () => new Date('2026-10-01T00:00:00Z') });
  const input = { start: '2026-10-05T12:00:00.000Z', end: '2026-10-05T12:30:00.000Z', idempotencyKey: 'same-key', bufferMinutes: 15 };
  const [one, two] = await Promise.all([service.book(input), service.book(input)]);
  assert.equal(one.eventId, two.eventId); assert.equal(one.meetLink, 'https://meet.google.com/abc-defg-hij'); assert.equal(creates, 1);
  await assert.rejects(service.book({ ...input, start: '2026-10-05T13:00:00.000Z', end: '2026-10-05T13:30:00.000Z' }), /key already used/);
  await assert.rejects(service.book({ ...input, idempotencyKey: 'other-key' }), /conflict/i);
});

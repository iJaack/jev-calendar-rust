import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { spawn } from 'node:child_process';
import { createServer } from 'node:net';
import { once } from 'node:events';
import { SqliteStore } from '../lib/store.js';

async function freePort() {
  const socket = createServer().listen(0, '127.0.0.1');
  await once(socket, 'listening');
  const port = socket.address().port;
  await new Promise(resolve => socket.close(resolve));
  return port;
}

test('private owner booking HTTP API is scoped, bounded, and excludes guest secrets', async t => {
  const dir = mkdtempSync(join(tmpdir(), 'jev-owner-bookings-'));
  const path = join(dir, 'fixture.sqlite');
  const store = new SqliteStore({ path, encryptionSecret: 'fixture-key' });
  store.db.prepare('INSERT INTO bookings (idempotency_key,source_id,start,end,buffer_minutes,guest_name,guest_email,meeting_title,status,event_id,meet_link,revision,pending_change,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
    .run('private-capability-key', null, '2030-10-07T09:00:00.000Z', '2030-10-07T09:30:00.000Z', 10, 'Private Guest', 'private@example.test', 'Private meeting', 'confirmed', 'google-secret-id', 'https://meet.google.com/private', 2, JSON.stringify({ action: 'reschedule', etag: 'secret-etag' }), '2026-09-26T12:00:00.000Z');
  store.db.prepare('INSERT INTO bookings (idempotency_key,source_id,start,end,buffer_minutes,status,created_at) VALUES (?,?,?,?,?,?,?)')
    .run('another-private-key', null, '2030-10-08T09:00:00.000Z', '2030-10-08T09:30:00.000Z', 10, 'cancelled', '2026-09-27T12:00:00.000Z');
  store.db.close();
  const port = await freePort();
  const origin = `http://127.0.0.1:${port}`;
  const token = 'fixture-only-owner-read-token-32-chars';
  const child = spawn(process.execPath, ['server.js'], { cwd: new URL('..', import.meta.url), env: { PATH: process.env.PATH, PORT: String(port), DATABASE_PATH: path, APP_ENCRYPTION_KEY: 'fixture-key', DEMO_MODE: 'true', APP_BASE_URL: origin, JEV_JAACK_OS_READ_TOKEN: token }, stdio: ['ignore', 'pipe', 'pipe'] });
  t.after(async () => { if (child.exitCode === null) { child.kill(); await once(child, 'exit'); } rmSync(dir, { recursive: true, force: true }); });
  await Promise.race([once(child.stdout, 'data'), once(child, 'exit').then(() => { throw new Error('Test server did not start'); })]);
  const route = '/api/integrations/jaack-os/bookings';
  const read = (suffix = '', authorization) => fetch(origin + route + suffix, { headers: authorization ? { Authorization: authorization } : {} });
  assert.equal((await read()).status, 401);
  assert.equal((await read('', 'Bearer wrong')).status, 401);
  assert.equal((await fetch(origin + route, { headers: { Cookie: 'jev_session=anything' } })).status, 401);
  assert.equal((await fetch(origin + route, { method: 'POST' })).status, 401);
  assert.equal((await fetch(origin + route, { method: 'POST', headers: { Authorization: `Bearer ${token}` } })).status, 405);
  assert.equal((await read('?limit=101', `Bearer ${token}`)).status, 400);
  const response = await read('?limit=1', `Bearer ${token}`);
  assert.equal(response.status, 200);
  assert.equal(response.headers.get('cache-control'), 'no-store');
  const firstPage = await response.json();
  assert.equal(firstPage.bookings.length, 1);
  assert.equal(firstPage.hasMore, true);
  assert.equal(firstPage.bookings[0].status, 'cancelled');
  const secondPage = await (await read('?limit=1&offset=1', `Bearer ${token}`)).json();
  assert.equal(secondPage.hasMore, false);
  const id = secondPage.bookings[0].id;
  assert.match(id, /^[a-f0-9]{64}$/);
  const detail = await read(`/${id}`, `Bearer ${token}`);
  assert.equal(detail.status, 200);
  const booking = (await detail.json()).booking;
  assert.deepEqual(booking, { id, source: 'jev-calendar', start: '2030-10-07T09:00:00.000Z', end: '2030-10-07T09:30:00.000Z', status: 'confirmed', revision: 2, pendingAction: 'reschedule', createdAt: '2026-09-26T12:00:00.000Z' });
  assert.equal((await read(`/${id}`, 'Bearer wrong')).status, 401);
  assert.equal((await read('/' + 'a'.repeat(64), `Bearer ${token}`)).status, 404);
  assert.doesNotMatch(JSON.stringify(firstPage) + JSON.stringify(secondPage) + JSON.stringify(booking), /private|@example|meet\.google|google-secret|etag|capability-key/i);
  const gatewayPort = await freePort();
  const gateway = spawn(process.execPath, ['public-server.js'], { cwd: new URL('..', import.meta.url), env: { PATH: process.env.PATH, PUBLIC_HOST: '127.0.0.1', PUBLIC_PORT: String(gatewayPort), INTERNAL_ORIGIN: origin }, stdio: ['ignore', 'pipe', 'pipe'] });
  t.after(async () => { if (gateway.exitCode === null) { gateway.kill(); await once(gateway, 'exit'); } });
  await Promise.race([once(gateway.stdout, 'data'), once(gateway, 'exit').then(() => { throw new Error('Test gateway did not start'); })]);
  const publicRead = await fetch(`http://127.0.0.1:${gatewayPort}${route}`, { headers: { Authorization: `Bearer ${token}` } });
  assert.equal(publicRead.status, 404);
});

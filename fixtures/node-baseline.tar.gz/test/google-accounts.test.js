import test from 'node:test';
import assert from 'node:assert/strict';
import { SqliteStore } from '../lib/store.js';
import { GoogleAccounts, GOOGLE_SCOPES } from '../lib/google-accounts.js';
import { MultiAccountCalendarAdapter } from '../lib/calendar.js';
import { BookingService } from '../lib/booking.js';
const token = (id, extra = {}) => ({ access_token: id, refresh_token: `refresh-${id}`, expires_at: Date.now() + 3600_000, scope: GOOGLE_SCOPES, ...extra });
const json = data => new Response(JSON.stringify(data));
function fixture(t, fetchImpl = async (url, init) => url.includes('/token') ? json(token(new URLSearchParams(init.body).get('code'))) : json({ items: [{ id: init.headers.Authorization.slice(7), primary: true }] })) {
  const store = new SqliteStore({ path: ':memory:', encryptionSecret: 'test' });
  t.after(() => store.db.close());
  return { store, manager: new GoogleAccounts({ store, clientId: 'test', clientSecret: 'test', baseUrl: 'https://private.test', fetchImpl }) };
}
async function connect(manager, { intent, session, accountId, code }) {
  const { nonce } = manager.begin({ intent, session, accountId });
  return manager.finish({ state: nonce, cookieNonce: nonce, session, code });
}
test('migrates encrypted legacy connection and booking ownership exactly once', async t => {
  const { store, manager } = fixture(t);
  store.putToken('google', token('owner@example.com'));
  store.reserve({ start: '2030-01-01T10:00:00Z', end: '2030-01-01T10:30:00Z', bufferMinutes: 10, idempotencyKey: 'legacy-booking' });
  await manager.migrate(); await manager.migrate();
  assert.equal(store.getToken('google'), null);
  assert.equal(manager.list().length, 1);
  assert.equal(store.getSetting('googleOwnerId'), 'owner@example.com');
  assert.equal(store.get('legacy-booking').googleAccountId, 'owner@example.com');
  assert.ok(!store.db.prepare('SELECT token FROM google_accounts').get().token.includes('refresh-owner'));
});
test('add, duplicate reconnect, explicit destination selection and disconnect preserve owner identity', async t => {
  const { store, manager } = fixture(t);
  await connect(manager, { intent: 'login', code: 'owner@example.com' });
  const session = store.newSession();
  await connect(manager, { intent: 'add', session, code: 'work@example.com' });
  await connect(manager, { intent: 'add', session, code: 'work@example.com' });
  assert.equal(manager.list().length, 2);
  assert.throws(() => store.disconnectGoogle('owner@example.com'), /Choose another/);
  store.selectGoogle('work@example.com'); store.disconnectGoogle('owner@example.com');
  assert.equal(store.getSetting('googleBookingAccountId'), 'work@example.com');
  await assert.rejects(connect(manager, { intent: 'login', code: 'work@example.com' }), /original dashboard owner/);
  store.disconnectGoogle('work@example.com');
  assert.equal(store.getSetting('googleOwnerId'), 'owner@example.com');
  assert.equal(store.getSetting('googleBookingAccountId'), null);
  assert.throws(() => manager.calendar(), /not connected/);
  assert.equal(store.validSession(session), true);
  await connect(manager, { intent: 'login', code: 'owner@example.com' });
  assert.equal(manager.list().length, 1);
});
test('OAuth rejects CSRF, replay, expiration, wrong reconnect identity, and absent owner session', async t => {
  const { store, manager } = fixture(t);
  store.connectGoogle('owner', token('owner'));
  const session = store.newSession();
  assert.throws(() => manager.begin({ intent: 'add' }), /sign-in/);
  const { nonce } = manager.begin({ intent: 'add', session });
  await assert.rejects(manager.finish({ state: nonce, cookieNonce: 'wrong', session, code: 'other' }), /expired/);
  await assert.rejects(manager.finish({ state: nonce, cookieNonce: nonce, session: store.newSession(), code: 'other' }), /sign-in/);
  await assert.rejects(manager.finish({ state: nonce, cookieNonce: nonce, session, code: 'other' }), /expired/);
  const expired = manager.begin({ intent: 'add', session }); manager.flows.get(expired.nonce).expires = 0;
  await assert.rejects(manager.finish({ state: expired.nonce, cookieNonce: expired.nonce, session, code: 'other' }), /expired/);
  await assert.rejects(connect(manager, { intent: 'reconnect', accountId: 'owner', session, code: 'wrong' }), /same Google account/);
  await assert.rejects(connect(manager, { intent: 'add', session, code: '' }), /cancelled/);
  assert.deepEqual(manager.list().map(x => x.id), ['owner']);
});
test('reconnection preserves refresh token and rejects partial calendar grants', async t => {
  let scopes = GOOGLE_SCOPES;
  const { store, manager } = fixture(t, async url => url.includes('/token') ? json({ access_token: 'new', scope: scopes }) : json({ items: [{ id: 'owner', primary: true }] }));
  store.connectGoogle('owner', token('owner'));
  const session = store.newSession();
  await connect(manager, { intent: 'reconnect', accountId: 'owner', session, code: 'yes' });
  assert.equal(store.googleAccount('owner').token.refresh_token, 'refresh-owner');
  scopes = 'https://www.googleapis.com/auth/calendar.events';
  await assert.rejects(connect(manager, { intent: 'add', session, code: 'yes' }), /all requested/);
  assert.equal(manager.list().length, 1);
});
test('an in-flight refresh cannot resurrect a disconnected or reconnected account', async t => {
  let resolve;
  const { store, manager } = fixture(t, () => new Promise(r => { resolve = r; }));
  store.connectGoogle('owner', token('owner', { expires_at: 0 }));
  const version = store.googleAccount('owner').version;
  const pending = manager.accessToken('owner', version);
  store.disconnectGoogle('owner');
  resolve(json({ access_token: 'stale' }));
  await assert.rejects(pending, /connections changed/);
  assert.equal(store.googleAccount('owner'), null);
  store.connectGoogle('owner', token('new'));
  assert.equal(store.refreshGoogle('owner', version, token('stale')), false);
});
test('all accounts block availability, shared trips deduplicate, and only the chosen account receives an invitation', async t => {
  const { store } = fixture(t);
  const range = { start: '2030-10-05T12:00:00Z', end: '2030-10-05T12:30:00Z' };
  const trip = { ...range, location: 'Rome', inPerson: true };
  let workBusy = true, failWork = false;
  const created = [];
  const accounts = ['personal', 'work'].map(id => ({ id, calendar: {
    freeBusy: async () => { if (id === 'work' && failWork) throw new Error('expired'); return id === 'work' && workBusy ? [range] : []; },
    events: async () => [trip], timeZone: async () => 'Europe/Rome', createEvent: async () => { created.push(id); return { id: 'event' }; }
  } }));
  const calendar = new MultiAccountCalendarAdapter({ accounts, destinationId: 'personal' });
  assert.deepEqual(await calendar.events(range), [trip]);
  const service = new BookingService({ store, calendar });
  const input = { ...range, googleAccountId: 'personal', bufferMinutes: 10, idempotencyKey: 'multi-account-busy' };
  await assert.rejects(service.book(input), /conflict/);
  assert.deepEqual(created, []);
  workBusy = false; failWork = true;
  await assert.rejects(calendar.freeBusy(range), /expired/);
  failWork = false;
  const result = await service.book({ ...input, idempotencyKey: 'multi-account-success' });
  assert.deepEqual(created, ['personal']);
  assert.equal(result.googleAccountId, 'personal');
});

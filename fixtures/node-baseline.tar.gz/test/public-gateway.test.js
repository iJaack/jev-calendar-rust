import test from 'node:test';
import assert from 'node:assert/strict';
import { allowedRoute, createRateLimiter, privateOwnerRedirect, publicHandler } from '../public-server.js';
import http from 'node:http';
import { once } from 'node:events';

test('owner shortcut redirects to the configured private origin without proxying owner routes', async t => {
  const previous = process.env.APP_BASE_URL;
  process.env.APP_BASE_URL = 'https://private-test.ts.net:3030';
  const server = http.createServer(publicHandler).listen(0, '127.0.0.1');
  await once(server, 'listening');
  t.after(async () => {
    if (previous === undefined) delete process.env.APP_BASE_URL; else process.env.APP_BASE_URL = previous;
    await new Promise(resolve => server.close(resolve));
  });
  const origin = `http://127.0.0.1:${server.address().port}`;
  const request = (path, method = 'GET') => new Promise((resolve, reject) => {
    const req = http.request(origin + path, { method, headers: { Host: 'book.jaack.me' } }, response => {
      let body = ''; response.on('data', chunk => { body += chunk; });
      response.on('end', () => resolve({ status: response.statusCode, headers: response.headers, body }));
    });
    req.on('error', reject); req.end();
  });
  for (const method of ['GET', 'HEAD']) {
    const response = await request('/owner?next=https://untrusted.test&code=not-forwarded', method);
    assert.equal(response.status, 302);
    assert.equal(response.headers.location, 'https://private-test.ts.net:3030/owner');
    assert.equal(response.headers['cache-control'], 'no-store');
    assert.equal(response.body, '');
  }
  for (const path of ['/api/settings', '/api/google/accounts', '/auth/google']) {
    assert.equal((await request(path)).status, 404);
  }
  assert.equal(privateOwnerRedirect('POST', '/owner', process.env.APP_BASE_URL), null);
  assert.equal(privateOwnerRedirect('GET', '/owner/settings', process.env.APP_BASE_URL), null);
  assert.equal(privateOwnerRedirect('GET', '/owner', 'https://book.jaack.me'), null);
  assert.equal(privateOwnerRedirect('GET', '/owner/', process.env.APP_BASE_URL), 'https://private-test.ts.net:3030/owner');
});

test('public gateway only exposes booking routes and static assets', () => {
  assert.equal(allowedRoute('GET', '/'), true);
  assert.equal(allowedRoute('GET', '/manage'), true);
  assert.equal(allowedRoute('GET', '/privacy'), true);
  for (const path of ['/api/booking/view', '/api/booking/slots', '/api/booking/change']) { assert.equal(allowedRoute('POST', path), true); assert.equal(allowedRoute('GET', path), false); }
  assert.equal(allowedRoute('GET', '/assets/public.js'), true);
  assert.equal(allowedRoute('POST', '/api/availability'), true);
  assert.equal(allowedRoute('POST', '/api/available-dates'), true);
  assert.equal(allowedRoute('POST', '/api/book'), true);
  for (const path of ['/api/google/accounts', '/api/google/connect']) for (const method of ['GET', 'POST', 'PUT', 'DELETE']) assert.equal(allowedRoute(method, path), false);
  assert.equal(allowedRoute('GET', '/owner'), false);
  assert.equal(allowedRoute('GET', '/auth/google'), false);
  assert.equal(allowedRoute('GET', '/auth/google/callback'), false);
  assert.equal(allowedRoute('GET', '/api/settings'), false);
  assert.equal(allowedRoute('PUT', '/api/settings'), false);
  assert.equal(allowedRoute('GET', '/api/workload'), false);
  assert.equal(allowedRoute('PUT', '/api/workload'), false);
  assert.equal(allowedRoute('POST', '/api/workload/refresh'), false);
});

test('rate limiter resets and blocks after its bounded allowance', () => {
  const limit = createRateLimiter({ limit: 2, windowMs: 1_000 });
  assert.equal(limit('visitor', 0).allowed, true);
  assert.equal(limit('visitor', 100).allowed, true);
  assert.equal(limit('visitor', 200).allowed, false);
  assert.equal(limit('visitor', 1_000).allowed, true);
});

# Jev Calendar

A standalone, dependency-light local booking app: public availability page, owner settings, Google Calendar OAuth/freebusy/event adapters, Google Routes travel constraints around the owner's in-person events, and a bounded Jev System One advisory client pinned to `jev-1.13.0`.

## Start in credential-free demo mode

```bash
cd /Users/jaack/clawd/apps/jev-calendar
npm test
npm start
# open http://localhost:3030
```

Demo mode is the default. It makes no Google or Jev request and uses explicitly labelled local calendar/route fixtures.
Working hours default to `Europe/Rome` and are converted with DST awareness before Calendar queries and booking. Visitors see and select times in their own IANA time zone. The host time zone is refreshed from the private owner device while its dashboard is active, then from the primary Google Calendar time-zone setting.

## Live Google setup

1. Create a Google Cloud OAuth Web Application with redirect URI `http://localhost:3030/auth/google/callback` (or your exact HTTPS `APP_BASE_URL`). Enable **Google Calendar API** and **Routes API**.
2. Copy `.env.example` to `.env`, set `DEMO_MODE=false`, and provide `APP_ENCRYPTION_KEY`, Google OAuth credentials, Routes API key, `TYPESAFE_API_KEY`, and `APP_BASE_URL`.
3. Export the values in your shell (this app deliberately has no dotenv dependency) and run `npm start`.
4. Open `/owner`, sign in with the owner account, and select a complete base address from the private Photon search before publishing `/`. Results use OpenStreetMap data and are cryptographically signed by the server before the canonical address and coordinates can be saved.

Google scopes cover Calendar events, free/busy across accessible calendars, and read-only calendar lists and settings. Existing connections must reconnect through the private `/auth/google` route to grant calendar-list and shared-calendar free/busy access. Timed event locations are read only to identify the owner's in-person commitments and calculate travel from or back to the private base location. Every visitor booking is remote by default: it requests a unique Google Meet conference, includes it in the invitation, and returns the Meet URL to the confirmation page. The app has no contacts or Drive scope.

### Google OAuth production configuration

The owner-only Google Auth Platform project uses a web client whose redirect URI is the private `APP_BASE_URL` plus `/auth/google/callback`. Guests do not sign in with Google. In Google Auth Platform, set the public application homepage to `https://book.jaack.me/` and privacy policy to `https://book.jaack.me/privacy`; the homepage links to that policy. Register `jaack.me` as an authorized domain and verify its ownership in Google Search Console. Keep the private Tailscale redirect URI and domain registered for the owner OAuth flow.

Declare every scope in `GOOGLE_SCOPES` on the Data Access page: `calendar.events`, `calendar.freebusy`, `calendar.events.freebusy`, `calendar.calendarlist.readonly`, and `calendar.settings.readonly`. Enable the Calendar and Routes APIs. After publishing the consent screen, reconnect the owner account once through the private dashboard so the saved refresh token is issued under the production publishing status. Read back the publishing status, granted scopes, connected account, and fresh live availability; publishing status alone does not verify a working booking.

## Deterministic scheduling contract

1. Google Calendar free/busy checks every calendar in every connected account’s calendar list, including hidden and unselected calendars and busy-only shares. Calendar lists and events are paginated; free/busy requests are batched at 50 calendars. A missing or failed calendar result blocks availability rather than silently treating it as free. Newly added calendars are discovered on the next request.
2. Online events use the owner minimum buffer. For each timed in-person Calendar event, Google Routes calculates the route between the private base location and that event in the required direction (a bootstrap driving route lets Jev choose an alternate mode; that chosen mode is queried from Google Routes again). If that alternate route fails, the driving route remains authoritative.
3. An in-person buffer is `ceil(route minutes) + owner minimum`; Jev can only select an allowed mode and add 0–15 minutes. Visitor locations are never requested or used.
4. Candidate generation rejects times before the owner's minimum advance notice, every overlap, and directional buffer violations. New events are written only to the primary calendar of the selected booking account. On confirmation, the notice cutoff is checked again, then a SQLite reservation and another Calendar free/busy check occur before creation of the Google Meet event.
   The public calendar checks a month at a time from one Calendar snapshot, disables dates with no slots for the selected duration and viewer time zone, and rechecks a date when selected. A date that empties between those checks is disabled immediately.
5. If Jev is absent, slow, or malformed, the app safely falls back to `DRIVE` with no extra advisory buffer. It never invents a duration.
   Each Jev choice must reach confidence `0.55` to be used; an uncertain mode uses `DRIVE`, and an uncertain extra margin uses 0 minutes. If both are uncertain, the whole advisory falls back. To diagnose a fallback, set `JEV_LOG_FALLBACK=1` in the private app's `.env` and restart it. Logs contain only a reason code and, for low confidence, the two confidence numbers; disable the flag afterward.

## Workload-aware availability

The private service refreshes a rolling four-week workload baseline on startup and checks it hourly, recalculating once per local day. It stores only aggregate busy minutes and typical minutes per project; event titles are used transiently for matching and are never stored in the learning snapshot or sent to TypeSafe. Live availability still reads current Google Calendar data, so changed events affect slots before the next daily baseline refresh. Confirmation and guest rescheduling use the same slot policy.

The owner can edit minimum advance notice in the private dashboard. Each daily workload refresh sends only aggregate busy and workload-type minutes for the next two workdays to Jev. Jev can keep the owner minimum or extend it by 50 or 100 percent; it cannot shorten it. If Jev is unavailable or uncertain, the owner minimum applies. A changed notice setting triggers a fresh workload check. The effective notice filters both the public month/day picker and final booking confirmation.

The private dashboard starts with the active and launching initiatives listed in Portfolio OS on 23 September 2026. Jaack can edit each project's calendar selections, title/calendar keywords, and default workload type. The title match takes precedence over a calendar match. Explicit event-title markers such as `[focus]`, `[meeting]`, or `[deadline]` override a project's default type. Busy-only shared calendars count toward overall load without exposing their event details. An unassigned event still counts as busy. On a heavy day, meeting work clusters bookings into at most two nearby slots; focus work offers edge-of-day slots to protect a long free block; at least two hours of deadline work closes the day. The baseline and current load set the heavy-day threshold. No project names or workload details are returned by public booking APIs.

The booking picker also protects focus across a whole workweek: where meetings already occupy one day, quieter days offer only edge slots, and the calendar suggests a better meeting day without hiding other bookable dates. An explicitly tagged deadline or a long project-matched deadline closes its day and progressively reduces slots over the preceding two workdays; normal availability resumes afterward. The public slot list ranks safe candidates using the current meeting pattern and a year of local confirmed, cancelled, and rescheduled booking outcomes. No guest identity is copied into the outcome history. Final booking and rescheduling recheck every candidate, even one that moved outside the first twelve displayed slots after ranking changed.

Each daily refresh also checks the next five workdays against the learned baseline. When the week is unusually full, Jev chooses a bounded private suggestion: cluster meetings, protect focus, or protect a deadline. Low-confidence or unavailable advice uses the deterministic suggestion. The owner dashboard shows the alert for review; it does not change Google Calendar or send a message.

## Scripts

- `npm test` — Node test suite
- `npm run check` — syntax check for server and libraries
- `npm start` — launch on `127.0.0.1:3030`
- `npm run start:public` — launch the allowlisted public gateway on `127.0.0.1:3031`; it exposes only the booking page/assets, health/config, availability, and booking APIs. Owner, OAuth, and settings routes remain private on the Tailscale origin.

### JAACK OS owner booking read API

Set a separate random `JEV_JAACK_OS_READ_TOKEN` (at least 32 characters) on the private service and send `Authorization: Bearer <token>` from the JAACK OS server. The public gateway never routes these paths. The token grants only `GET /api/integrations/jaack-os/bookings?limit=50&offset=0` (limit 1–100, offset 0–10,000), `GET /api/integrations/jaack-os/bookings/:id`, and the exact request-journal status route described below. The list returns `{bookings,hasMore,limit,offset}`; detail returns `{booking}`. Each booking contains an opaque SHA-256 ID, `source: "jev-calendar"`, `start`, `end`, `status`, `revision`, `pendingAction`, and `createdAt`. Missing or invalid credentials receive 401 even in demo mode. Unknown IDs receive 404. Responses are `no-store`.

These records are JEV's local booking ledger, not a live Google Calendar reconciliation. Guest names, emails, meeting titles, Meet links, Google IDs, idempotency keys, and management tokens are excluded. Keep the bearer token server side and use the detail endpoint for readback after a change.

### JAACK OS reviewed owner booking changes

The private `POST /api/integrations/jaack-os/bookings/:id/change` route is disabled until `JEV_JAACK_OS_WRITE_TOKEN` is set to a random value of at least 32 characters distinct from the read token. Keep it server side; the read token cannot authorize changes, and the public gateway does not route this path. A reviewed JAACK OS run must supply `Authorization: Bearer <write token>` and a stable UUID `Idempotency-Key` for the exact booking ID and request body. Cancellation accepts only `{ "action": "cancel", "revision": 0 }`. Rescheduling accepts only `action`, expected `revision`, `start`, `end`, `date`, and `viewerTimeZone`; use the selected future slot and its IANA time zone. The booking ID and revision come from the private owner read API.

JEV checks the expected revision and current Google event, preserves the original meeting length, and journals the request before attempting a provider change. A confirmed response returns the bounded owner booking and a `replayed` flag. The read-token route `GET /api/integrations/jaack-os/booking-changes/:requestId?sourceId=:id&requestHash=:sha256` returns only `{requestId,sourceId,requestHash,state}` for an exact UUID, booking ID, and normalized request hash; a mismatch returns 404. JAACK OS requires this journal to say `succeeded` **and** a fresh bounded booking readback to match the reviewed change before reporting success. A matching booking state alone cannot attribute the change to this request. A `503` with `state: "uncertain"` needs reconciliation; the JAACK OS worker does not resend automatically. A `409` means the scope is stale, conflicting, or already applied by a different request; prepare a new reviewed run after fresh source readback. Successful Google cancellation or rescheduling can notify attendees. No JAACK OS run should claim a booking change from preparation or dispatch alone.

See [THREAT-AND-PRIVACY.md](./THREAT-AND-PRIVACY.md) for the security model and known MVP limits.

## Guest cancellation and rescheduling

New invitations include **Cancel** and **Reschedule** links, also available on the booking confirmation page. Opening a link only shows the meeting; a guest must explicitly confirm a cancellation or a new time. Rescheduling checks all connected calendars and travel buffers again, updates the original event on its original Google account, preserves the meeting length and Meet link, and requests attendee notifications. Cancellation removes that event and requests cancellation notifications.

The original slot stays reserved until a move succeeds. Changes are allowed before the meeting starts. If a Google response is lost, the app saves the pending request and reconciles the event before retrying. Reconnect the original account if it has been disconnected. Existing invitations are not automatically rewritten or emailed again.

Management links grant access to that booking: keep them private. They use signed tokens in URL fragments, accepted only by the public `/api/booking/view`, `/api/booking/slots`, and `/api/booking/change` POST endpoints. `/manage` is public; owner settings and account credentials remain private. Rotating `APP_ENCRYPTION_KEY` also invalidates these links.

## Production surfaces

- Public booking: `https://book.jaack.me` through a named Cloudflare Tunnel to the allowlisted gateway on `127.0.0.1:3031`.
- Dashboard shortcut: `https://book.jaack.me/owner` redirects to the private Tailscale dashboard configured by `APP_BASE_URL`. Tailscale remains required; owner APIs and OAuth are not exposed publicly.
- Private owner/OAuth: the configured Tailscale HTTPS origin on `127.0.0.1:3030`. `/owner`, OAuth, and settings are never routed through the public gateway.
- The private app, public gateway, and tunnel are supervised by separate user LaunchAgents. Deployment source lives in `deploy/`; tunnel credentials stay in `~/.cloudflared/`.

## Multiple Google accounts

In the private dashboard, use **Connect another account** and choose a Google account. Grant all requested Calendar permissions. Each account gets its own encrypted credentials; reconnecting the same account updates it without duplication. All calendars from every connected account contribute to availability and travel checks, with shared trips deduplicated. If any account cannot be checked, availability fails closed.

Use **Use for new bookings** to choose the account whose primary calendar sends invitations and creates Meet links. Before disconnecting that account, select another destination if other accounts remain. Disconnect removes only this app's stored credentials; it neither deletes existing meetings nor revokes unrelated Google grants. Disconnecting the last account pauses live booking. The original owner identity is retained for dashboard sign-in even if its calendar is disconnected; signing in as the owner reconnects that account. Additional connected accounts cannot sign into the dashboard.

The previous single-account token is migrated automatically with existing bookings attributed to that account. Account metadata and tokens stay private; `/api/google/accounts` and `/api/google/connect` are blocked by the public gateway. Account mutations require the owner session, same-origin request, and custom owner header. Add/reconnect OAuth callbacks are bound to that owner's session, a single-use cookie nonce, and a ten-minute expiry. Destination changes and disconnects serialize with booking creation. Token refreshes cannot restore a disconnected account.

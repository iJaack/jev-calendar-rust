const $ = id => document.getElementById(id);
const fragment = new URLSearchParams(window.location.hash.slice(1));
const token = fragment.get('token');
const initialAction = fragment.get('action');
let booking, choice, generation = 0, changing = false;
let timezone = Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC';
const supported = typeof Intl.supportedValuesOf === 'function' ? Intl.supportedValuesOf('timeZone') : ['UTC', 'Europe/Rome'];
for (const zone of [...new Set([timezone, 'UTC', ...supported])].sort()) {
  const option = document.createElement('option'); option.value = zone; option.textContent = zone.replaceAll('_', ' '); option.selected = zone === timezone; $('manage-timezone').append(option);
}
function dateKey(value) { return new Intl.DateTimeFormat('en-CA', {timeZone: timezone, year:'numeric', month:'2-digit', day:'2-digit'}).format(new Date(value)); }
function dateTime(value) { return new Intl.DateTimeFormat('en-US', {timeZone: timezone, weekday:'long', month:'long', day:'numeric', hour:'numeric', minute:'2-digit', timeZoneName:'short'}).format(new Date(value)); }
function status(text = '', error = false) { $('manage-status').textContent = text; $('manage-status').className = `status${error ? ' error' : ''}${text ? '' : ' hidden'}`; }
async function request(action, body = {}) {
  const response = await fetch(`/api/booking/${action}`, {method:'POST',headers:{'Content-Type':'application/json','X-Jev-Booking':'1'},body:JSON.stringify({...body,token})});
  const data = await response.json(); if (!response.ok) throw new Error(data.error || 'Could not update this meeting. Please try again.'); return data;
}
function render() {
  $('meeting-heading').textContent = booking.meetingTitle || 'Meeting with Jaack';
  $('meeting-summary').replaceChildren();
  const title = document.createElement('strong'); title.textContent = booking.status === 'cancelled' ? 'Meeting cancelled' : dateTime(booking.start);
  const detail = document.createElement('span'); detail.textContent = booking.status === 'cancelled' ? 'This meeting is no longer scheduled.' : `${(Date.parse(booking.end)-Date.parse(booking.start))/60000} minutes · Google Meet`;
  $('meeting-summary').append(title,detail);
  $('manage-actions').classList.toggle('hidden', !booking.canChange || Boolean(booking.pendingAction));
  $('pending-change').classList.toggle('hidden', !booking.pendingAction);
  $('cancel-confirmation').classList.add('hidden'); $('reschedule-panel').classList.add('hidden');
  if (!booking.canChange && booking.status !== 'cancelled') status('This meeting has already started. Please contact Jaack for changes.');
}
async function load() { booking = await request('view'); render(); }
async function loadSlots() {
  const current = ++generation;
  choice = null; $('confirm-reschedule').disabled = true; $('new-time-summary').textContent = '';
  if (!$('new-date').value) { $('new-slots').textContent = 'Choose a date to see available times.'; return; }
  $('new-slots').textContent = 'Checking all calendars…';
  try {
    const data = await request('slots', {date:$('new-date').value,viewerTimeZone:timezone});
    if (current !== generation) return;
    $('new-slots').replaceChildren();
    if (!data.candidates.length) { $('new-slots').textContent = 'No available times on this date. Choose another date.'; return; }
    for (const slot of data.candidates) {
      const button = document.createElement('button'); button.type='button'; button.className='account-button';
      button.textContent = new Intl.DateTimeFormat('en-US',{timeZone:timezone,hour:'numeric',minute:'2-digit'}).format(new Date(slot.start));
      button.setAttribute('aria-pressed','false');
      button.addEventListener('click',()=>{
        choice=slot; for(const other of $('new-slots').querySelectorAll('button')) { other.classList.remove('selected');other.setAttribute('aria-pressed','false'); }
        button.classList.add('selected');button.setAttribute('aria-pressed','true');
        $('new-time-summary').textContent = `New time: ${dateTime(slot.start)}`; $('confirm-reschedule').disabled=false;
      });
      $('new-slots').append(button);
    }
  } catch(error) { if (current === generation) $('new-slots').textContent=error.message; }
}
function showReschedule() {
  status(); $('cancel-confirmation').classList.add('hidden'); $('reschedule-panel').classList.remove('hidden');
  $('new-date').min=dateKey(Date.now());
  $('new-date').value=dateKey(booking.start); $('new-date').focus(); loadSlots();
}
function showCancel() { status(); ++generation; $('reschedule-panel').classList.add('hidden'); $('cancel-confirmation').classList.remove('hidden'); $('keep-meeting').focus(); }
async function change(action, extra = {}) {
  if (changing) return; changing = true; ++generation;
  const buttons = [...document.querySelectorAll('button')]; buttons.forEach(button=>button.disabled=true);
  status(action === 'cancel' ? 'Cancelling your meeting…' : 'Checking and updating your meeting…');
  try {
    booking = await request('change',{action,revision:booking.revision,...extra}); render();
    status(booking.status === 'cancelled' ? 'Your meeting is cancelled. A cancellation notice has been requested for the attendees.' : 'Your meeting has been updated. The calendar invitation reflects the new time.');
  } catch(error) {
    const message=error.message; try { await load(); } catch { /* Preserve the original actionable error. */ } status(message,true);
  } finally { changing=false; buttons.forEach(button=>button.disabled=false);$('confirm-reschedule').disabled=true;choice=null; }
}
$('show-reschedule').addEventListener('click',showReschedule);
$('show-cancel').addEventListener('click',showCancel);
$('keep-meeting').addEventListener('click',()=>{ $('cancel-confirmation').classList.add('hidden');$('show-cancel').focus(); });
$('confirm-cancel').addEventListener('click',()=>change('cancel'));
$('retry-change').addEventListener('click',()=>change('retry'));
$('confirm-reschedule').addEventListener('click',()=>{ if(choice) change('reschedule',{...choice,date:$('new-date').value,viewerTimeZone:timezone}); });
$('new-date').addEventListener('change',loadSlots);
$('manage-timezone').addEventListener('change',()=>{ timezone=$('manage-timezone').value; $('new-date').min=dateKey(Date.now()); loadSlots(); });
if (!token) { $('meeting-heading').textContent='Open your invitation link';status('Use the cancel or reschedule link in your calendar invitation to manage your meeting.',true); }
else {
  try { await load(); if (booking.canChange && !booking.pendingAction) { if(initialAction==='cancel') showCancel();else if(initialAction==='reschedule') showReschedule(); } }
  catch(error) { $('meeting-heading').textContent='Meeting unavailable';status(error.message,true); }
}
fetch('/api/config').then(response=>response.json()).then(config=>{ if(config.demo) $('management-demo').textContent='Demo preview · no calendar emails sent'; }).catch(()=>{});

#!/bin/zsh
set -e
cd /Users/jaack/clawd/apps/jev-calendar
set -a
source .env
set +a
export PUBLIC_HOST=book.jaack.me
export PUBLIC_PORT=3031
export INTERNAL_ORIGIN=http://127.0.0.1:3030
exec /opt/homebrew/bin/node public-server.js

#!/bin/zsh
set -e
cd /Users/jaack/clawd/apps/jev-calendar
set -a
source .env
set +a
export DEMO_MODE=false
export NODE_ENV=production
exec /opt/homebrew/bin/node server.js

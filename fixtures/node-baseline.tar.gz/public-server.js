import http from 'node:http';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { resolve } from 'node:path';

const publicHost = process.env.PUBLIC_HOST || 'book.jaack.me';
const publicOrigin = `https://${publicHost}`;
const upstream = process.env.INTERNAL_ORIGIN || 'http://127.0.0.1:3030';
const port = Number(process.env.PUBLIC_PORT || 3031);
const MAX_BODY = 100_000;
const managementLimit = createRateLimiter({ limit: 60, windowMs: 15 * 60_000 });
const availabilityLimit = createRateLimiter({ limit: 30, windowMs: 15 * 60_000 });
const bookingLimit = createRateLimiter({ limit: 5, windowMs: 60 * 60_000 });

export function privateOwnerRedirect(method, pathname, privateBaseUrl = process.env.APP_BASE_URL) {
  if (!['GET', 'HEAD'].includes(method) || !['/owner', '/owner/'].includes(pathname) || !privateBaseUrl) return null;
  const target = new URL('/owner', privateBaseUrl);
  if (target.origin === publicOrigin) return null;
  return target.href;
}

export function allowedRoute(method, pathname) {
  if ((method === 'GET' || method === 'HEAD') && (pathname === '/' || pathname === '/manage' || pathname === '/privacy' || pathname === '/api/config' || pathname === '/health' || pathname.startsWith('/assets/'))) return true;
  return method === 'POST' && ['/api/availability', '/api/available-dates', '/api/book', '/api/booking/view', '/api/booking/slots', '/api/booking/change'].includes(pathname);
}

export function createRateLimiter({ limit, windowMs }) {
  const entries = new Map();
  return (key, now = Date.now()) => {
    const old = entries.get(key);
    const entry = !old || now >= old.resetAt ? { count: 0, resetAt: now + windowMs } : old;
    entry.count += 1; entries.set(key, entry);
    if (entries.size > 10_000) for (const [item, value] of entries) if (now >= value.resetAt) entries.delete(item);
    return { allowed: entry.count <= limit, retryAfter: Math.max(1, Math.ceil((entry.resetAt - now) / 1000)) };
  };
}

function clientKey(request) {
  const raw = String(request.headers['cf-connecting-ip'] || request.socket.remoteAddress || 'unknown').slice(0, 100);
  return createHash('sha256').update(raw).digest('hex').slice(0, 16);
}
function reply(response, status, body, headers = {}) {
  response.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...headers });
  response.end(JSON.stringify(body));
}
function securityHeaders() {
  return {
    'Content-Security-Policy': "default-src 'self'; base-uri 'none'; connect-src 'self'; form-action 'self'; frame-ancestors 'none'; img-src 'self' data:; object-src 'none'; script-src 'self'; style-src 'self'",
    'Permissions-Policy': 'camera=(), microphone=(), geolocation=(), payment=()',
    'Referrer-Policy': 'strict-origin-when-cross-origin',
    'Strict-Transport-Security': 'max-age=31536000; includeSubDomains',
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY'
  };
}
async function readBody(request) {
  const chunks = []; let size = 0;
  for await (const chunk of request) { size += chunk.length; if (size > MAX_BODY) throw new Error('Request too large'); chunks.push(chunk); }
  return Buffer.concat(chunks);
}

export async function publicHandler(request, response) {
  const url = new URL(request.url, publicOrigin);
  const method = request.method || 'GET';
  const key = clientKey(request);
  const log = (status) => console.log(JSON.stringify({ at: new Date().toISOString(), method, path: url.pathname, status, client: key }));
  try {
    if (String(request.headers.host || '').split(':')[0] !== publicHost) { log(421); return reply(response, 421, { error: 'Misdirected request' }, securityHeaders()); }
    const ownerRedirect = privateOwnerRedirect(method, url.pathname);
    if (ownerRedirect) {
      log(302);
      response.writeHead(302, { ...securityHeaders(), 'Cache-Control': 'no-store', Location: ownerRedirect });
      return response.end();
    }
    if (!allowedRoute(method, url.pathname)) { log(404); return reply(response, 404, { error: 'Not found' }, securityHeaders()); }
    if (method === 'POST') {
      if (!String(request.headers['content-type'] || '').toLowerCase().startsWith('application/json')) { log(415); return reply(response, 415, { error: 'JSON required' }, securityHeaders()); }
      if (request.headers.origin && request.headers.origin !== publicOrigin) { log(403); return reply(response, 403, { error: 'Origin denied' }, securityHeaders()); }
      if (request.headers['sec-fetch-site'] && request.headers['sec-fetch-site'] !== 'same-origin') { log(403); return reply(response, 403, { error: 'Cross-site request denied' }, securityHeaders()); }
      if (request.headers['x-jev-booking'] !== '1') { log(403); return reply(response, 403, { error: 'Request verification failed' }, securityHeaders()); }
      const verdict = (url.pathname.startsWith('/api/booking/') ? managementLimit : url.pathname === '/api/book' ? bookingLimit : availabilityLimit)(key);
      if (!verdict.allowed) { log(429); return reply(response, 429, { error: 'Too many requests. Please try again later.' }, { ...securityHeaders(), 'Retry-After': String(verdict.retryAfter) }); }
    }
    const body = method === 'POST' ? await readBody(request) : undefined;
    if (method === 'POST') {
      let input; try { input = JSON.parse(body.toString('utf8')); } catch { log(400); return reply(response, 400, { error: 'Invalid JSON' }, securityHeaders()); }
      if (!input || typeof input !== 'object' || Array.isArray(input)) { log(400); return reply(response, 400, { error: 'Invalid request' }, securityHeaders()); }
      if (url.pathname === '/api/book') {
        const email = String(input.guestEmail || '').trim();
        if (!String(input.guestName || '').trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { log(400); return reply(response, 400, { error: 'A valid name and email are required' }, securityHeaders()); }
      }
    }
    const upstreamResponse = await fetch(`${upstream}${url.pathname}${url.search}`, { method, headers: method === 'POST' ? { 'Content-Type': 'application/json' } : {}, body, redirect: 'manual', signal: AbortSignal.timeout(30_000) });
    const headers = securityHeaders();
    const type = upstreamResponse.headers.get('content-type'); if (type) headers['Content-Type'] = type;
    headers['Cache-Control'] = url.pathname.startsWith('/assets/') ? 'public, max-age=300' : 'no-store';
    response.writeHead(upstreamResponse.status, headers);
    if (method === 'HEAD') response.end(); else response.end(Buffer.from(await upstreamResponse.arrayBuffer()));
    log(upstreamResponse.status);
  } catch (error) {
    const status = error.message === 'Request too large' ? 413 : 502; log(status); reply(response, status, { error: status === 413 ? error.message : 'Booking service temporarily unavailable' }, securityHeaders());
  }
}

if (process.argv[1] && fileURLToPath(import.meta.url) === resolve(process.argv[1])) {
  http.createServer(publicHandler).listen(port, '127.0.0.1', () => console.log(`Jev public booking gateway listening at http://127.0.0.1:${port} for ${publicHost}`));
}
